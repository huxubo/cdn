$('.body_box').css('opacity', 1);
var json = {};
var max_channel_index = 0;
var new_c_isclick = false;

function getJson() {
    $('#channellistnotice').show();
    $.ajax({
        'url': "./api/categories.json",
        'type': "get",
        'data': {},
        'dataType': "json",
        'success': function(a) {
            json = a;
            if (a.data.length > 0) {
                getDiyList();
                $("#channellistnotice").hide();
            } else {
                $("#channellistnotice").hide();
                toastr.error("嘿嘿！快去创建一个分类吧！");
            }
        },
        'error': function x(b) {
            $("#channellistnotice").hide();
            toastr.error('获取分类失败...');
        }
    });
}


function toUtf8(a) {
    var b, c, d, e;
    b = '';
    d = a.length;
    for (c = 0; c < d; c++) {
        e = a.charCodeAt(c);
        if ((e >= 1) && e <= 127) {
            b += a.charAt(c);
        } else {
            if (e > 2047) {
                b += String.fromCharCode(224 | e >> 12 & 15);
                b += String.fromCharCode(128 | (e >> 6) & 63);
                b += String.fromCharCode(128 | e >> 0 & 63);
            } else {
                b += String.fromCharCode(192 | (e >> 6) & 31);
                b += String.fromCharCode(128 | e >> 0 & 63);
            }
        }
    }
    return b;
}



function getMaxSortIndex() {
    var a = max_channel_index;
    var b = '';
    for (var c = 0; c < json.data.length; c++) {
        if (json.data[c].name.indexOf('#', 1) >= 0) {
            b = json.data[c].name.split('#')[1];
            var d = Number(json.data[c].name.split('#')[0]);
            if (d >= max_channel_index) {
                max_channel_index = d;
                a = max_channel_index;
            }
        }
    }
    return ++a;
}

function getDiyList() {
    ($(".channel_list")).html('');
    var a = '';
    for (var b = 0; b < json.data.length; b++) {
        for (var c = -1; c < json.data.length - b; c++) {
            if (json.data[b].name.indexOf('#', 1) >= 0) {
                try {
                    var d = Number(json.data[c].name.split('#')[0]);
                    var e = Number(json.data[c + 1].name.split('#')[0]);
                    if (d > e) {
                        var f = json.data[c];
                        json.data[c] = json.data[c + 1];
                        json.data[c + 1] = f;
                    }
                } catch (g) {}
            }
        }
    }
    for (var b = 0; b < json.data.length; b++) {
        var h = Number(json.data[b].data.split('\n').length - 1);
        var i = '';
        if (json.data[b].name.indexOf('#', 1) >= 0) {
            i = json.data[b].name.split('#')[1];
            var d = Number(json.data[b].name.split('#')[0]);
            if (d > max_channel_index) {
                max_channel_index = d;
            }
        } else {
            i = json.data[b].name;
        }
        a += (((((("<li data-curclick=\"cleft_" + b) + "\"  id=\"curclick_") + json.data[b].id) + "\" class=\"cleft list-group-item\"><input style=\"display:none;\" value=\"") + json.data[b].id + '" /><span class="badge">') + h) + "</span>" + i + "</li>";
    }
    if (!json.data.length > 0) {
        $(".channel_list").html('');
    } else {
        ($(".channel_list")).html(a);
    }
}
$('.channel_list').on('click', '.cleft', function() {
    new_c_isclick = false;
    var a = $(this).attr("data-curclick").split('_')[1];
    cur_category_name = json.data[a].name;
    ($('.channel_list li')).each(function() {
        $(this).removeClass("list_active");
    });
    $(this).addClass("list_active");
    try {
        sort = cur_category_name.split('#')[0];
        if (sort >= 0) {
            ($(".category_name")).val(cur_category_name.split('#')[1]);
            $(".sort_index").val(sort);
        } else {
            $('.category_name').val(cur_category_name);
            ($(".sort_index")).val(getMaxSortIndex());
        }
    } catch (b) {
        console.log("error");
        ($(".category_name")).val(cur_category_name);
        ($(".sort_index")).val(getMaxSortIndex());
    }
    $("#detail_content").val(json.data[a].data);
});
$('.channel_list').on('click', '.cleft_new', function() {
    ($(".channel_list li")).each(function() {
        ($(this)).removeClass("list_active");
    });
    $(this).addClass("list_active");
    new_c_isclick = true;
    var a = getMaxSortIndex();
    ($(".category_name")).val("新分类" + a);
    $(".sort_index").val(getMaxSortIndex());
    $("#detail_content").val('');
});

function add_category() {
    if (($("ul > .cleft_new")).length > 0) {
        alert("您已经创建了一个新分类,先编辑他！");
        return;
    }($(".channel_list li")).each(function() {
        $(this).removeClass("list_active");
    });
    var a = getMaxSortIndex();
    var b = (("<li data-curclick=\"cleft_new_" + a + "\" id=\"cleft_") + a + '\" class=\"list_active cleft_new list-group-item\" ><input style=\"display:none;\" value=\"' + a) + '" /><span class="badge">0</span>新分类' + a + "</li>";
    ($('.channel_list')).append(b);
    new_c_isclick = true;
    var a = getMaxSortIndex();
    ($(".category_name")).val("新分类" + a);
    ($('.sort_index')).val(getMaxSortIndex());
    $('#detail_content').val('');
}
var notice = '<div class=\"i_footer\"><div id=\"foot_notice\" style=\"color: #338888; font-size: 15px;margin:0 auto;\">EZ视频</div></div>';
$('body').append(notice);

function del_category() {
    var a = ($(".list_active")).find('input').val();
    if (new_c_isclick) {
        max_channel_index--;
        ($(".cleft_new")).remove();
        $.ajax({
            'url': "./api/delete.json",
            'type': 'get',
            'data': {
                'id': a
            },
            'dataType': "json",
            'success': function(b) {
                json = b;
                if (b.data != null) {
                    getDiyList();
                }
            }
        });
    } else {
        $.ajax({
            'url': "./api/delete.json",
            'type': "get",
            'data': {
                'id': a
            },
            'dataType': "json",
            'success': function(c) {
                json = c;
                if (c.data != null) {
                    getDiyList();
                }
            }
        });
    }
    clear_detail();
    getMaxSortIndex();
}

function clear_detail() {
    ($(".category_name")).val('');
    $("#detail_content").val('');
    ($(".sort_index")).val(0);
}

function save_category() {
    var a = Number($(".sort_index").val());
    var b = $('.list_active');
    var c = -1;
    try {
        c = ($(".list_active")).find('input').val();
    } catch (d) {
        alert("请选择分类！");
        return;
    }
    if (c < 0 || typeof c == "undefined") {
        alert('请选择分类！');
        return;
    }
    if (a < 1 || a == '') {
        a = getMaxSortIndex();
    }
    var e = $(".category_name").val();
    var f = $("#detail_content").val();
    var g = new Base64();
    var h = {
        'id': g.encode(c),
        'name': g.encode((a + '#') + e),
        'data': g.encode(f)
    };
    $.ajax({
        'url': './api/category.json',
        'type': "post",
        'data': JSON.stringify(h),
        'contentType': "application/json",
        'dataType': 'text',
        'success': function(y) {
            json = JSON.parse(y);
            getDiyList();
            getMaxSortIndex();
            ($('#' + $(b).attr('id'))).trigger("clcik");
            ($('#' + $(b).attr('id'))).addClass('list_active');
        },
        'error': function x(j) {
            toastr.error("保存失败...");
        }
    });
}

function Base64() {
    _keyStr = 'ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789+/=';
    this.encode = function(a) {
        var b = '';
        var c, d, e, f, g, h, y;
        var j = 0;
        a = _utf8_encode(a);
        while (j < a.length) {
            c = a.charCodeAt(j++);
            d = a.charCodeAt(j++);
            e = a.charCodeAt(j++);
            f = c >> 2;
            g = c & 3 << 4 | d >> 4;
            h = d & 15 << 2 | e >> 6;
            y = e & 63;
            if (isNaN(d)) {
                h = y = 64;
            } else {
                if (isNaN(e)) {
                    y = 64;
                }
            }
            b = (b + _keyStr.charAt(f)) + _keyStr.charAt(g) + _keyStr.charAt(h) + _keyStr.charAt(y);
        }
    };
    this.decode = function(a) {
        var b = '';
        var c, d, e;
        var f, g, h, y;
        var j = 0;
        a = a.replace(/[^A-Za-z0-9\+\/\=]/g, '');
        while (j < a.length) {
            f = _keyStr.indexOf(a.charAt(j++));
            g = _keyStr.indexOf(a.charAt(j++));
            h = _keyStr.indexOf(a.charAt(j++));
            y = _keyStr.indexOf(a.charAt(j++));
            c = f << 2 | g >> 4;
            d = g & 15 << 4 | h >> 2;
            e = (h & 3) << 6 | y;
            k = k + String.fromCharCode(c);
            if (h != 64) {
                k = k + String.fromCharCode(d);
            }
            if (y != 64) {
                k = k + String.fromCharCode(e);
            }
        }
        k = _utf8_decode(k);
        return k;
    };
    _utf8_encode = function(a) {
        a = a.replace(/\r\n/g, '\n');
        var b = '';
        for (var c = 0; c < a.length; c++) {
            var d = a.charCodeAt(c);
            if (d < 128) {
                b += String.fromCharCode(d);
            } else {
                if ((d > 127) && d < 2048) {
                    b += String.fromCharCode(d >> 6 | 192);
                    b += String.fromCharCode(d & 63 | 128);
                } else {
                    b += String.fromCharCode(d >> 12 | 224);
                    b += String.fromCharCode(d >> 6 & 63 | 128);
                    b += String.fromCharCode(d & 63 | 128);
                }
            }
        }
        return b;
    };
    _utf8_decode = function(a) {
        var b = '';
        var c = 0;
        var d = c1 = c2 = 0;
        while (c < a.length) {
            d = a.charCodeAt(c);
            if (d < 128) {
                b += String.fromCharCode(d);
                c++;
            } else {
                if (d > 191 && d < 224) {
                    c2 = a.charCodeAt(c + 1);
                    b += String.fromCharCode(d & 31 << 6 | c2 & 63);
                    c += 2;
                } else {
                    c2 = a.charCodeAt(c + 1);
                    c3 = a.charCodeAt(c + 2);
                    b += String.fromCharCode(d & 15 << 12 | (c2 & 63) << 6 | c3 & 63);
                    c += 3;
                }
            }
        }
    };
}
var okurl = '';
var timeouturl = '';
var okurlnum = 0;
var timeouturlnum = 0;


function ajax_url(a) {
    $.ajax({
        'url': a,
        'type': "GET",
        'headers': {
            'accept': "*/*",
            'connection': "Keep-Alive"
        },
        'complete': function(b) {
            if (b.status == 200) {
                return true;
            } else {
                return false;
            }
        }
    });
}


toastr.options = {
    'closeButton': false,
    'debug': false,
    'progressBar': false,
    'positionClass': 'toast-top-right',
    'onclick': null,
    'showDuration': '300',
    'hideDuration': '1000',
    'timeOut': '2000',
    'extendedTimeOut': '1000',
    'showEasing': 'swing',
    'hideEasing': 'linear',
    'showMethod': 'fadeIn',
    'hideMethod': 'fadeOut'
};