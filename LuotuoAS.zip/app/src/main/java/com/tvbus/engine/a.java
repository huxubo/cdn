package com.tvbus.engine;

import org.json.JSONException;
import org.json.JSONObject;

import android.content.Intent;

import com.vv.test.Play;
import com.vv.test.PlayerActivity;

public class a implements d{
	TVCore tvCore;
	a(TVCore tvCore){
		this.tvCore=tvCore;
	}
	@Override
	public void onInfo(String arg0) {
		// TODO Auto-generated method stub
		
	}
	@Override
	public void onInited(String arg0) {
		// TODO Auto-generated method stub
		
	}
	@Override
	public void onPrepared(String json) {
		JSONObject jsonObject;
		try {
			jsonObject = new JSONObject(json);
			PlayerActivity.playUrl=jsonObject.optString("hls");
			Intent intent=new Intent("TVBUS_ONPREPARED");
			PlayerActivity.context.sendBroadcast(intent);
		} catch (JSONException e) {
			e.printStackTrace();
		}
		
	}
	@Override
	public void onQuit(String arg0) {
		// TODO Auto-generated method stub
		
	}
	@Override
	public void onStart(String arg0) {
		// TODO Auto-generated method stub
		
	}
	@Override
	public void onStop(String arg0) {
		// TODO Auto-generated method stub
		
	}
}
