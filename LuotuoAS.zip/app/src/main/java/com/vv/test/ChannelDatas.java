package com.vv.test;

import java.io.BufferedReader;
import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.FileReader;
import java.io.IOException;
import java.io.OutputStreamWriter;
import java.io.UnsupportedEncodingException;
import java.util.ArrayList;
import java.util.Collection;
import java.util.Collections;
import java.util.Comparator;
import java.util.HashMap;
import java.util.List;
import java.util.zip.Inflater;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import com.setting.MySettings;

import android.content.Context;
import android.os.Environment;
import android.util.Base64;
import android.widget.Toast;

public class ChannelDatas extends ArrayList<ChannelData> {
	private static final long serialVersionUID = 1L;
	public static ArrayList<String> categoryList;
	private String jsonString;
	private MySettings mySettings;
	public static final String FILE_DATA="data"+SplashActivity.myappver;
	public static final String DIR_DIY=Environment.getExternalStorageDirectory().getPath() +"/"+SplashActivity.appname;
	public ChannelDatas(Context context) {
		mySettings=new MySettings(context);
		
		int index=7;
		
		String sKey=AES.pmd5(SplashActivity.sKey+new MySettings(PlayerActivity.context).getSettingStr("rand"));
		String code=sKey.substring(index,index+16);	
		try {
			jsonString=ChannelManager.readfile(context, FILE_DATA);
			
			jsonString=jsonString.substring(64);
			jsonString=jsonString.substring(64);
			
			jsonString=jsonString.replace("f", "#");
			jsonString=jsonString.replace("b", "f");
			jsonString=jsonString.replace("#", "b");
			
			jsonString=jsonString.replace("t", "%");
			jsonString=jsonString.replace("y", "t");
			jsonString=jsonString.replace("%", "y");
			jsonString=AES.Decrypt(jsonString, code);
			jsonString=new String(gzuncompress(Base64.decode(jsonString, Base64.DEFAULT)),"UTF-8");
			
		} catch (Exception e) {
			e.printStackTrace();
			new MySettings(PlayerActivity.context).saveVersion(0);
			Toast.makeText(PlayerActivity.context, "解析节目数据失败！请重新启动软件！", Toast.LENGTH_LONG).show();
		}
	}
	public void loadData(){
		try {
			categoryList=new ArrayList<String>();
			JSONArray dataArray=new JSONArray(jsonString);
			for(int i=0;i<dataArray.length();i++){
				ChannelData channelData=new ChannelData();
				JSONObject jsonCategorys=dataArray.getJSONObject(i);
				channelData.name=jsonCategorys.optString("name");
				channelData.psw=jsonCategorys.optString("psw","");
				
				if(!channelData.name.equals("我的收藏"))categoryList.add(channelData.name);
				if(mySettings.getSettingboolean("Hide"+channelData.name)){
					continue;
				}
				
				JSONArray channelArray=jsonCategorys.optJSONArray("data");
				if(channelArray!=null){
					for(int j=0;j<channelArray.length();j++){
						ChannelObject channelObject=new ChannelObject();
						JSONObject jsonChannel=channelArray.getJSONObject(j);
						channelObject.num=jsonChannel.optInt("num");
						channelObject.name=jsonChannel.optString("name");
						JSONArray srcJsonArray =jsonChannel.optJSONArray("source");
						if(srcJsonArray!=null){
							for(int k=0;k<srcJsonArray.length();k++){
								channelObject.source.add(srcJsonArray.optString(k));
							}
						}
						channelData.data.add(channelObject);
					}
				}
				add(channelData);
			}
		} catch (JSONException e) {
			e.printStackTrace();
		}
		loadDiy();
	}
	public void loadFavor(FavorList favorList) {
		try {
			for(int i=0;i<favorList.size();i++){
				int type = favorList.get(i).type;
				int pos = favorList.get(i).pos;
				if(type>0&&type<size()&&pos>=0&&pos<get(type).data.size()){
					get(0).data.add(get(type).data.get(pos));
				}
			}
		} catch (Exception e) {
		}
	}

	 public void loadDiy() {
		  try {
			  
			  File file = new File(DIR_DIY);
			  if(!file.exists()){
				  file.mkdirs();
			  }
			  File[] listFiles = file.listFiles();
			  if(null==listFiles)return;
			  
			  List<File> list = new ArrayList<File>();
			  for(File file1:listFiles){
				  if(file1.isFile()&&file1.getName().endsWith(".txt")){
					  list.add(file1);
				  }
			  }
			  Collections.sort(list, new Comparator<File>() {
				@Override
				public int compare(File f1, File f2) {
					if(!f1.getName().contains("#")){
						return 1;
					}else{
						if(!f2.getName().contains("#")){
							return -1;
						}else{
							
							int id1=Integer.parseInt(f1.getName().split("#")[0]);
							int id2=Integer.parseInt(f2.getName().split("#")[0]);
							if(id1>id2){
								return 1;
							}else{
								return -1;
							}
						}
					}
				}
			});
			  
			  for (File file2 : list) {
				  String name = file2.getName();
				  ChannelData channelData=new ChannelData();
				  if(name.endsWith(".txt")){
					  if(name.contains("#")){
						  name=name.split("#")[1];
					  }
					  if(name.contains("_")&&name.indexOf("_")>0&&name.indexOf("_")<name.length()-1){
						  channelData.name=name.split("_")[0];
						  channelData.psw=name.substring(0,name.lastIndexOf(".")).split("_")[1];
					  }else{
						  channelData.name=name.substring(0,name.lastIndexOf("."));
						  channelData.psw="";
					  }

					  try {
						  FileReader fr = new FileReader(file2);
						  BufferedReader bf = new BufferedReader(fr);
						  String str;
						  
						  ArrayList<String> nameArrayList=new ArrayList<String>();
						  ArrayList<ArrayList<String>> sourceArrayList=new ArrayList<ArrayList<String>>();
						  while ((str = bf.readLine()) != null) {
							  if(str.contains(",")){
								  String channelname =str.substring(0,str.indexOf(","));
								  String srcString=str.substring(str.indexOf(",")+1);
								  //读入数据到数组中
								  ArrayList<String> srcArrayList=new ArrayList<String>();
								  if(srcString.contains("#")){
									  for (String src : srcString.split("#")) {
										  srcArrayList.add(src);
									  }
								  }else{
									  srcArrayList.add(srcString);
								  }
								  if(!nameArrayList.contains(channelname)){
									  nameArrayList.add(channelname);
									  sourceArrayList.add(srcArrayList);
								  }else{
									  int pos=nameArrayList.indexOf(channelname);
									  sourceArrayList.get(pos).addAll(srcArrayList);
								  }
							  }
						  }
						  
						  int num=getLastChannel()+1;
						  for (int i=0;i<nameArrayList.size();i++) {
							  ChannelObject channelObject=new ChannelObject();
							channelObject.num=num;
							  channelObject.name=nameArrayList.get(i);
							  channelObject.source=sourceArrayList.get(i);
							  channelData.data.add(channelObject);
							  num++;
						  }
						  bf.close();
						  fr.close();
						  add(channelData);
					  } catch (IOException e) {
						  e.printStackTrace();
					  }
				  }
			  }
		} catch (Exception e) {
		}
	}
	
	public static void savetoDiy(String name,String data){
		try {
			FileOutputStream out =new FileOutputStream(new File(DIR_DIY+"/"+name+".txt"));
			OutputStreamWriter osw = new OutputStreamWriter(out, "UTF-8");
			osw.write(data);
			osw.close();
			out.close();
			PlayerActivity.loadChannelData();
		} catch (FileNotFoundException e) {
			e.printStackTrace();
		} catch (UnsupportedEncodingException e) {
			e.printStackTrace();
		} catch (IOException e) {
			e.printStackTrace();
		}
	}
	public static void deleteFromDiy(int deleteId){
		try {
			File file = new File(DIR_DIY);
			File[] listFiles = file.listFiles();
			if(null==listFiles)return;
			  int id=0;
			  for (File file2 : listFiles) {
				id++;
				if(id==deleteId){
					file2.delete();
				}
			  }
			  PlayerActivity.loadChannelData();
		} catch (Exception e) {
			e.printStackTrace();
		}
	}
	
	public static JSONObject jsonArrayFromDiy(){
		JSONObject jsonObject=new JSONObject();
		File file = new File(DIR_DIY);
		  if(!file.exists()){
			  file.mkdirs();
		  }
		  try {
			File[] listFiles = file.listFiles();
			if(null==listFiles)return null;
			  JSONArray jsonArray=new JSONArray();
			  int id=0;
			  for (File file2 : listFiles) {
				id++;
				String name = file2.getName();
				if(name.endsWith(".txt")){
					name=name.substring(0,name.lastIndexOf("."));
					JSONObject object=new JSONObject();
					object.put("id", ""+id);
					object.put("name",name);
					String data="";
					try {
						FileReader fr = new FileReader(file2);
						BufferedReader bf = new BufferedReader(fr);
						String str="";
						while ((str = bf.readLine()) != null) {
							if(str.contains(",")){
								data+=str+"\r\n";
							}
						}
						bf.close();
						fr.close();
					} catch (IOException e) {
							e.printStackTrace();
					}
					object.put("data", data);
					jsonArray.put(object);
				}
			  }
			  jsonObject.put("data", jsonArray);
		} catch (JSONException e) {
			e.printStackTrace();
		}
		return jsonObject;
	}
	
	public static void clearDiy(){
		 try {
			File file = new File(DIR_DIY);
			  if(!file.exists()){
				  file.mkdirs();
			  }
			  File[] listFiles = file.listFiles();
			  if(null==listFiles)return;
			  for (File file2 : listFiles) {
				  file2.delete();
			  }
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	public HashMap<String, Integer> getChannel(int num){
		HashMap<String, Integer> map=new HashMap<String, Integer>();
		try {
			for(int i=0;i<size();i++){
				for(int j=0;j<get(i).data.size();j++){
					if(num==get(i).data.get(j).num){
						map.put("type", i);
						map.put("pos", j);
						return map;
					}
				}
			}
		} catch (Exception e) {
		}
		map.put("type", 0);
		map.put("pos", 0);
		return map;
	}
	public int getLastChannel(){
		try {
			return get(size()-1).data.get(get(size()-1).data.size()-1).num;
		} catch (Exception e) {
			return 0;
		}
		
	}
	public static byte[] gzuncompress(byte[] data) {
        byte[] unCompressed = null;
        ByteArrayOutputStream bos = new ByteArrayOutputStream(data.length);
        Inflater deCompressor = new Inflater();
        try {
            deCompressor.setInput(data);
            final byte[] buf = new byte[256];
            while (!deCompressor.finished()) {
                int count = deCompressor.inflate(buf);
                bos.write(buf, 0, count);
            }
            unCompressed = bos.toByteArray();
            bos.close();
        } catch (Exception e) {
            e.printStackTrace();
        } finally {
            deCompressor.end();
        }
 
        return unCompressed;
    }      
	public String toJson(){
		try {
			String json="[";
			for(int i=0;i<size();i++){
				if(i==0){
					json+=get(i).toJson();
				}else{
					json+=","+get(i).toJson();
				}
			}
			json+="]";
			return json;
		} catch (Exception e) {
		}
		return "";
	}

}
