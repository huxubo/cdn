package com.vv.test;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;

public class AutoStartReceiver extends BroadcastReceiver {
	
	@Override
	public void onReceive(Context context, Intent intent) {

		if (intent.getAction().equals("android.intent.action.BOOT_COMPLETED")) {
			SharedPreferences sp = context.getSharedPreferences("live",
					Context.MODE_PRIVATE);
			boolean autoStart = sp.getBoolean("autoStart", false);
			if (autoStart) {
				Intent i = new Intent(context, SplashActivity.class);
				i.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
				context.startActivity(i);
			}
		}
	
	}

}
