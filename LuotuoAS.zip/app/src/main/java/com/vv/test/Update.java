package com.vv.test;

import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.net.HttpURLConnection;
import java.net.URL;

import org.json.JSONException;
import org.json.JSONObject;

import com.setting.MySettings;

import android.app.ProgressDialog;
import android.content.Context;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.content.pm.PackageManager.NameNotFoundException;
import android.net.Uri;
import android.os.Build;
import android.os.Environment;
import android.os.Handler;
import android.os.Message;
import android.widget.Toast;

public class Update {
private Context context;
private boolean isDownLoading;
private ProgressDialog progressDialog;
private String serverVer="V1.0";
private OnCheckCompleteListener checkCompleteListener;
private OnChannelDataUpdated channelDataUpdated;
private Handler handler =new Handler(){
	public void handleMessage(Message msg) {
		if(msg.what==Play.CHECK_UPDATE){
			downloadfile();
		}
	};
};
public String appurl;
public Update(Context context){
	this.context=context;
}

public MySettings mySettings;
public String dataurl;
public String netType;
public String randkey;
public String mac;
public String androidid;
public String model;
public String appname;
public String region;

public void updateChannelData(){
	new Thread(new Runnable() {
		@Override
		public void run() {
			try {
				JSONObject param=new JSONObject();
				param.put("region", region);
				param.put("nettype", netType);
				param.put("rand", randkey);
				param.put("mac", mac);
				param.put("androidid", androidid);
				param.put("model", model);
				param.put("appname", appname);
				
				String aesString =HttpRequest.sendPost(dataurl, "data="+param.toString());
				ChannelManager.clearFiles(context);
				ChannelManager.writefile(context, ChannelDatas.FILE_DATA, aesString);
				mySettings.saveSetting("rand", randkey);
				channelDataUpdated.onUpdateComplete();
			} catch (Exception e) {
				
			}
		}
	}).start();
}
public void setOnChannelUpdated(OnChannelDataUpdated l){
	channelDataUpdated=l;
}



public void checkUpdate(final String verName){
	new Thread(new Runnable() {
		@Override
		public void run() {
			try {
//				String jsonUrl=HttpRequest.httpget("http://kktv.suntv.xyz/kktv.txt", "GetHost").trim();
//				JSONObject jsonObject=new JSONObject(jsonUrl);
//				SplashActivity.host=jsonObject.optString("url");
				
				String json=HttpRequest.httpget(SplashActivity.host+"/getver.php", "UA");
				JSONObject object=new JSONObject(json);
				serverVer=object.optString("appver");
				if(serverVer.startsWith("V")){
					serverVer=serverVer.toUpperCase().replace("V", "");
				}
				String myver=verName;
				if(myver.startsWith("V")){
					myver.toUpperCase().replace("V", "");
				}
				appurl=object.optString("appurl");
				if(myver.compareTo(serverVer)<0){
					handler.sendEmptyMessage(Play.CHECK_UPDATE);
					checkCompleteListener.onNeedUpdate();
				}else{
					checkCompleteListener.onNotNeedUpdate();
				}
			} catch (JSONException e) {
				e.printStackTrace();
				checkCompleteListener.onError();
			}
			
		}
	}).start();
	
}

public void setOnCheckCompleteListener(OnCheckCompleteListener l){
	checkCompleteListener=l;
}

public void downloadfile(){
	if(isDownLoading){
		if(progressDialog!=null)progressDialog.show();
		return;
	}
	isDownLoading=true;
	progressDialog =  new ProgressDialog(context);//实例化ProgressDialog
    progressDialog.setMax(100);//设置最大值
    progressDialog.setTitle("正在更新软件");//设置标题
    progressDialog.setProgressStyle(ProgressDialog.STYLE_HORIZONTAL);//设置样式为横向显示进度的样式
    progressDialog.setMessage("正在下载，请等待！");
    progressDialog.incrementProgressBy(0);//设置初始值为0，其实可以不用设置，默认就是0
    progressDialog.setIndeterminate(false);//是否精确显示对话框，flase为是，反之为否
    progressDialog.setCancelable(false);

    progressDialog.show();
	new download().start();
}

private void installAPK(){
	Intent intent = new Intent(Intent.ACTION_VIEW);
	String type = "application/vnd.android.package-archive";
	Uri apkPath = Uri.fromFile(new File(Environment.getExternalStorageDirectory(),"tmpTV.apk"));
	intent.setDataAndType(apkPath , type);
	context.startActivity(intent);
}
class download extends Thread{
	@Override
	public void run() {
		HttpURLConnection  connection=null;
		InputStream input=null;
		OutputStream output=null;
		try {
			URL url = new URL(appurl);
			connection = (HttpURLConnection) url.openConnection();
			connection.setRequestProperty("Accept-Encoding", "identity");
	        connection.connect();
	        File file = new File(Environment.getExternalStorageDirectory (),"tmpTV.apk");
	        input = connection.getInputStream();
	        output = new FileOutputStream(file);
	        byte data[] = new byte[1024];
	        int count;
	        int total=0;
	        int fileLength=connection.getContentLength();
	        while ((count = input.read(data)) != -1) {
	        	output.write(data, 0, count);
	        	total+=count;
				progressDialog.setProgress(total*100/fileLength);
	        }
			isDownLoading=false;
			installAPK();
		} catch (Exception e) {
			e.printStackTrace();
			isDownLoading=false;
		}finally{
			 try {
	             if (output != null)
	                 output.close();
	             if (input != null)
	                 input.close();
	         } catch (IOException ignored) {
	         }
	         if (connection != null)
	             connection.disconnect();
	     }
		
	}
}
}
