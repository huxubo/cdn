package com.vv.test;

public interface OnChannelDataUpdated {
	public void onUpdateComplete();
		
}
