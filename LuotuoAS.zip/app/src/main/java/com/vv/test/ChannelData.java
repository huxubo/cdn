package com.vv.test;

import java.util.ArrayList;

public class ChannelData {
	public String name;
	public ArrayList<ChannelObject> data=new ArrayList<ChannelObject>();
	public String psw="";
	protected boolean hasPassed=false;
	public String toJson(){
		String json="";
		json="{\"name\":\""+name+"\",\"data\":[";
		for(int i=0;i<data.size();i++){
			if(i==0){
				json+=data.get(i).toJson();
			}else{
				json+=","+data.get(i).toJson();
			}
		}
		json+="]}";
		return json;
	}
}
