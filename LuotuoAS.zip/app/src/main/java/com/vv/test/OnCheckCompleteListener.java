package com.vv.test;

public interface OnCheckCompleteListener {
	public void onNeedUpdate();
	public void onNotNeedUpdate();
	public void onError();
		
}
