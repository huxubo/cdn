package com.vv.test;


import java.io.InputStreamReader;
import java.io.LineNumberReader;
import java.net.NetworkInterface;
import java.util.ArrayList;
import java.util.Enumeration;
import java.util.regex.Pattern;

import org.json.JSONArray;
import org.json.JSONObject;

import com.gsoft.mitv.MainActivity;
import com.setting.MySettings;
import com.tvbus.engine.TVCore;

import android.app.Activity;
import android.content.Context;
import android.content.Intent;
import android.content.pm.PackageInfo;
import android.content.pm.PackageManager;
import android.content.pm.PackageManager.NameNotFoundException;
import android.graphics.drawable.Drawable;
import android.net.wifi.WifiInfo;
import android.net.wifi.WifiManager;
import android.os.Build;
import android.os.Bundle;
import android.os.Handler;
import android.os.Message;
import android.provider.Settings;
import android.text.TextUtils;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.Button;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;

public class SplashActivity extends Activity implements OnClickListener {
	public static String mac;
	public static String appVer;
	public static int dataVer;
	public static int avalibledDays = -1;
	public static String adText;
	public static int showinterval;
	public static String region;
	public static String appurl;
	public static String qqinfo;
	public static String randkey;
	private MySettings mySettings = new MySettings(this);

	public static String host = "http://www.162526.xyz/iptv";
	private Thread tcheckupdate;

	private Handler handler = new Handler() {

		public void handleMessage(Message msg) {

			switch (msg.what) {
				case 100:
					tv_second.setVisibility(View.VISIBLE);
					tv_second.setText(msg.obj.toString());
					break;
				case 0:
					tv_loading_tip.setText(msg.obj.toString());
					break;
				case 10:
					tv_loading_info.setText("");
					break;
				case 3:
					tv_loading_info.setText(msg.obj.toString());
					break;
				case 1:
					// 用户登录成功
					et_Sn.setVisibility(View.INVISIBLE);
					tv_mac.setVisibility(View.INVISIBLE);
					tv_account.setVisibility(View.INVISIBLE);
					tv_loading_tip.setVisibility(View.INVISIBLE);
					findViewById(R.id.num_parent).setVisibility(View.INVISIBLE);
					tv_loading_info.setText("用户登录成功");
					if (bj != null)
						ll_bj.setBackground(bj);

					tcheckupdate = new Thread(new Runnable() {
							@Override
							public void run() {
								try {
									checkUpdateData();
								} catch (Exception e) {
								}
							}
						});
					tcheckupdate.start();
					new Thread(new Runnable() {
							@Override
							public void run() {
								try {
									String bg = HttpRequest.httpget(host + "/bg.php",
																	"MyTV/1.0");
									ChannelManager
										.downLoad(bg, getApplicationContext());
								} catch (Exception e) {
								}
							}
						}).start();
					mySettings.saveSetting("userid", userid);
					break;
				case 2:
					// 用户登录失败
					ll_bj.setBackgroundResource(R.drawable.home_bg);
					et_Sn.setVisibility(View.VISIBLE);
					tv_mac.setVisibility(View.VISIBLE);
					tv_account.setVisibility(View.VISIBLE);
					findViewById(R.id.num_parent).setVisibility(View.VISIBLE);
					break;
				case 8:
					tv_mac.setVisibility(View.VISIBLE);
					break;
				case Play.PREPARE_LOGIN:
					login();
					break;
				default:
					break;
			}
		}


	};
	private void HideText(int i) {
		if(r!=null){
			handler.removeCallbacks(r);
		}else{
			r = new Runnable() {
				@Override
				public void run() {
					handler.sendEmptyMessage(10);
				}
			};
		}
		handler.postDelayed(r, i);
	};
	private TextView tv_loading_tip;
	public static String dataurl;
	private String json = "";
	public static String strLocation = "未知";
	private String deviceid;
	public static int sig;
	public static int showtime;
	public static String netType = "";
	private EditText et_Sn;
	public static String model;
	public static String androidid;
	public static String meal;
	public static int decoder;
	public static String tiploading;
	private String tipusernoreg;
	private String tipuserexpired;
	private String tipuserforbidden;
	public static String userid;
	private TextView tv_mac;
	private LinearLayout ll_bj;
	private Drawable bj;
	public static String myappver = "";
	private int setver;
	public static int buffTimeOut;
	public static String packagename;
	public static ArrayList<String> canseekArrayList;
	public static String appname;
	public static String sKey;
	public static JSONArray arrSrc;
	public static JSONArray arrProxy;
	public static ArrayList<String> arrProvList = new ArrayList<String>();
	public static int status;
	private Thread tlogin;
	private TextView tv_account;
	private TextView tv_loading_info;
	private Runnable r;
	private TextView tv_second;
	public static int updateinterval=15;
	public static int autoupdate;

	public static int getPackageCode(Context context) {
		PackageManager manager = context.getPackageManager();
		int code = 0;
		try {
			PackageInfo info = manager.getPackageInfo(context.getPackageName(),
													  0);
			code = info.versionCode;
		} catch (PackageManager.NameNotFoundException e) {
			e.printStackTrace();
		}
		return code;

	}

	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.splash);
		if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M
			&& checkSelfPermission(android.Manifest.permission.WRITE_EXTERNAL_STORAGE) != PackageManager.PERMISSION_GRANTED) {
			String[] permissions = {
				"android.permission.RECEIVE_BOOT_COMPLETED",
				"android.permission.READ_PHONE_STATE",
				"android.permission.READ_EXTERNAL_STORAGE",
				"android.permission.WRITE_EXTERNAL_STORAGE" };
			requestPermissions(permissions, 1);
		}

		tv_loading_tip = (TextView) findViewById(R.id.tv_loading_tipinfo);
		tv_loading_info = (TextView) findViewById(R.id.tv_loadinginfo);
		et_Sn = (EditText) findViewById(R.id.et_sn);
		tv_mac = (TextView) findViewById(R.id.tv_mac);
		tv_account = (TextView) findViewById(R.id.tv_account);
		//et_Sn.setText(mySettings.getSettingStr("userid"));
		findViewById(R.id.num_0).setOnClickListener(this);
		findViewById(R.id.num_1).setOnClickListener(this);
		findViewById(R.id.num_2).setOnClickListener(this);
		findViewById(R.id.num_3).setOnClickListener(this);
		findViewById(R.id.num_4).setOnClickListener(this);
		findViewById(R.id.num_5).setOnClickListener(this);
		findViewById(R.id.num_6).setOnClickListener(this);
		findViewById(R.id.num_7).setOnClickListener(this);
		findViewById(R.id.num_8).setOnClickListener(this);
		findViewById(R.id.num_9).setOnClickListener(this);
		findViewById(R.id.num_del).setOnClickListener(this);
		findViewById(R.id.num_OK).setOnClickListener(this);
		tv_second = (TextView) findViewById(R.id.seconds);
		try {
			myappver = getPackageManager().getPackageInfo(getPackageName(), 0).versionName;
			appname = getPackageManager()
				.getApplicationLabel(
				(getPackageManager().getPackageInfo(
					getPackageName(), 0).applicationInfo))
				.toString();
			packagename = getPackageName();
			androidid = getAndroidId(this);
			sig = getSignatrue();
			mac = getMac();
			deviceid = getDeviceID();
			model = getModel();
			sig = 12315;
		} catch (NameNotFoundException e) {
			e.printStackTrace();
		}
		tv_mac.setText("MAC：" + mac);

		sKey = AES.pmd5(sig + appname + packagename + mySettings.getSign());
		sKey=AES.pmd5(sKey+appname+packagename);

		TVCore.get();
		startService(new Intent(this, MainActivity.class));

		try {
			Bundle extras = getIntent().getExtras();
			if(extras!=null){
				if(extras.getString("parent").equals("player")){
					sendTipMessage("请输入新的授权帐号绑定使用");
					return;
				}
			}
		} catch (Exception e) {
		}

		bj = Drawable.createFromPath(getFilesDir() + "/home_bj.png");
		ll_bj = (LinearLayout) findViewById(R.id.ll_splash);
		if (bj != null) {
			ll_bj.setBackground(bj);
			et_Sn.setVisibility(View.INVISIBLE);
			tv_mac.setVisibility(View.INVISIBLE);
			tv_account.setVisibility(View.INVISIBLE);
			findViewById(R.id.num_parent).setVisibility(View.INVISIBLE);
		}
		Update update = new Update(this);
    	update.setOnCheckCompleteListener(new OnCheckCompleteListener() {
				@Override
				public void onNotNeedUpdate() {
					sendMessage(Play.PREPARE_LOGIN);
					sendLoadingMessage("");
				}

				@Override
				public void onNeedUpdate() {
					sendLoadingMessage("软件正在升级中！");
				}
				@Override
				public void onError() {
					sendLoadingMessage("网络连接失败!");
				}
			});
    	sendLoadingMessage("正在检查更新");
    	update.checkUpdate(myappver);



	}

	/*
	 * 方法二：推荐，速度最快 判断是否为整数
	 * 
	 * @param str 传入的字符串
	 * 
	 * @return 是整数返回true,否则返回false
	 */
	private boolean isInteger(String str) {
		Pattern pattern = Pattern.compile("^[-\\+]?[\\d]*$");
		return pattern.matcher(str).matches();
	}

	@Override
	protected void onResume() {
		super.onResume();
	}

	@Override
	protected void onDestroy() {
		if (tlogin != null)
			tlogin.interrupt();
		if (tcheckupdate != null)
			tcheckupdate.interrupt();
		super.onDestroy();
	}

	private void login() {
		new Thread(new Runnable() {
				@Override
				public void run() {
					val();
				}
			}).start();
	}

	private void relogin() {
		tlogin = new Thread(new Runnable() {
				@Override
				public void run() {
					try {
						Thread.sleep(3000);
						val();
					} catch (InterruptedException e) {
					}

				}
			});
		tlogin.start();
	}

	private void val() {
		try {
			try {
				json=HttpRequest.httpget("http://ip.taobao.com/service/getIpInfo.php?ip=myip", "MiTV");
				JSONObject tbip=new JSONObject(json);
				JSONObject tbipdata=tbip.optJSONObject("data");
				strLocation=tbipdata.optString("region")+tbipdata.optString("city")+tbipdata.optString("isp");
				netType=tbipdata.optString("isp");
			} catch (Exception e) {
				strLocation="";
				netType="";
			}

			JSONObject param = new JSONObject();
			param.put("region", strLocation);
			param.put("mac", mac);
			param.put("androidid", androidid);
			param.put("model", model);
			param.put("nettype", netType);
			param.put("appname", appname);


			String url = host + "/login3.php";
			json = HttpRequest.sendPost(url, "login=" + param.toString());
		} catch (Exception e) {
			sendLoadingMessage("网络连接失败！");
			relogin();
			return;
		}
		try {
			json = AES.Decrypt(json, sKey.substring(5, 21));
			JSONObject jsonObject = new JSONObject(json);
			status = jsonObject.optInt("status");
			dataurl = jsonObject.optString("dataurl");
			dataVer = jsonObject.optInt("dataver");
			appVer = jsonObject.optString("appver");
			setver = jsonObject.optInt("setver");
			appurl = jsonObject.optString("appurl");
			adText = jsonObject.optString("adtext");
			meal = jsonObject.optString("meal");
			jsonObject.optString("ip");
			showinterval = jsonObject.optInt("showinterval");
			jsonObject.optInt("categoryCount");
			avalibledDays = jsonObject.optInt("exp");
			showtime = jsonObject.optInt("showtime");
			buffTimeOut = jsonObject.optInt("buffTimeOut") * 1000;
			arrSrc = jsonObject.optJSONArray("arrsrc");
			arrProxy=jsonObject.optJSONArray("arrproxy");
			JSONArray provList = jsonObject.optJSONArray("provlist");
			qqinfo = jsonObject.optString("qqinfo", "");
			strLocation = jsonObject.optString("location");
			netType = jsonObject.optString("nettype");
			randkey = jsonObject.optString("randkey");
			updateinterval=jsonObject.optInt("updateinterval");
			autoupdate = jsonObject.optInt("autoupdate");

			if(updateinterval<=0)updateinterval=15;
			updateinterval=updateinterval*60000;

			JSONArray canseeklist = jsonObject.optJSONArray("canseeklist");
			canseekArrayList = new ArrayList<String>();
			canseekArrayList.add("303543214");
			try {
				for (int i = 0; i < canseeklist.length(); i++) {
					canseekArrayList.add(canseeklist.optString(i));
				}
				for (int i = 0; i < provList.length(); i++) {
					arrProvList.add(provList.optString(i));
				}
			} catch (Exception e) {
			}
			userid = jsonObject.optString("id");
			decoder = jsonObject.optInt("decoder");
			tiploading = jsonObject.optString("tiploading");
			tipusernoreg = jsonObject.optString("tipusernoreg");
			tipuserexpired = jsonObject.optString("tipuserexpired");
			tipuserforbidden = jsonObject.optString("tipuserforbidden");
			//套餐显示
			meal = jsonObject.optString("meal");
			if (meal.length() < 1) {                   
				meal = jsonObject.optString("meals");
			}
			if (meal.length() < 1) {                   
				meal = "暂无套餐";
			}
			
			region = strLocation.substring(0, 2);
			if (region.equals("黑龙")) {
				region = "黑龙江";
			} else if (region.equals("内蒙")) {
				region = "内蒙古";
			}
			region = mySettings.getSettingStr("prov", region);
			if (!region.equals(mySettings.getregion())
				|| !netType.equals(mySettings.getNetType())) {
				mySettings.saveregion(region);
			}
			if (setver > mySettings.getLocalSetVer()) {
				mySettings.clearSetting();
				mySettings.saveSetVer(setver);
			}
			if (status == 999||status==5) {
				sendMessage(1);
			} else if (status == 1) {
				if (avalibledDays > 0) {
					sendMessage(1);
				} else {
					sendTipMessage(tipuserexpired);
					sendMessage(2);
					relogin();
				}
			} else if (status == 0) {
				sendTipMessage(tipuserforbidden);
				sendMessage(2);
				relogin();
			} else {
				sendTipMessage(tipusernoreg);
				sendMessage(2);
				relogin();
			}

		} catch (Exception e) {
			e.printStackTrace();
			sendLoadingMessage("登录时发生错误！");
			relogin();
		}
	}

	private String bytesToHex(byte[] bytes) {
		StringBuffer sb = new StringBuffer();
		for (int i = 0; i < bytes.length; i++) {
			String hex = Integer.toHexString(bytes[i] & 0xFF);
			if (hex.length() < 2) {
				sb.append(0);
			}
			sb.append(hex);
			if (i != bytes.length - 1) {
				sb.append(":");
			}
		}
		return sb.toString();
	}

	private String getMac() {
		mac = mySettings.getmac();
		if (TextUtils.isEmpty(mac)) {
			mac = lan_mac();
			if (TextUtils.isEmpty(mac) || !mac.contains(":")) {
				mac = getMac("eth0");
			}
			if (TextUtils.isEmpty(mac)) {
				mac = getMac("wlan0");
			}
			if (TextUtils.isEmpty(mac)) {
				mac = wlan_address();
			}
		}
		if (!TextUtils.isEmpty(mac)) {
			if (mac.contains("00:00:00")) {
				mac = "获取地址失败，请开启WiFi功能。";
			} else {
				mySettings.savemac(mac);
			}
		}
		return mac;
	}

	private String lan_mac() {
		String str = "";
		try {
			LineNumberReader lReader = new LineNumberReader(
				new InputStreamReader(Runtime.getRuntime()
									  .exec("cat /sys/class/net/eth0/address")
									  .getInputStream()));
			str = lReader.readLine().trim();
		} catch (Exception e) {
		}
		return str;
	}

	private String wlan_address() {
		WifiInfo wifiInfo = ((WifiManager) getSystemService("wifi"))
			.getConnectionInfo();
		if (wifiInfo != null) {
			String macAddress = wifiInfo.getMacAddress();
			if (!TextUtils.isEmpty(macAddress)) {
				return macAddress.trim();
			}
		}
		return "";
	}

	private String getMac(String intname) {
		try {
			Enumeration<NetworkInterface> networkInterfaces = NetworkInterface
				.getNetworkInterfaces();
			NetworkInterface networkInterface = null;
			while (networkInterfaces.hasMoreElements()) {
				networkInterface = (NetworkInterface) networkInterfaces
					.nextElement();
				if (networkInterface.getName().equals(intname)) {
					return bytesToHex(networkInterface.getHardwareAddress());
				}
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
		return "";

	}

	private String getModel() {
		return android.os.Build.MODEL;
	}

	private String getDeviceID() {
		return android.os.Build.SERIAL;

	}

	private String getAndroidId(Context context) {
		String ANDROID_ID = Settings.System.getString(
			context.getContentResolver(), Settings.System.ANDROID_ID);
		return ANDROID_ID;
	}

	private void loadMainActivity() {
		Intent intent = new Intent(getApplicationContext(),
								   PlayerActivity.class);
		startActivity(intent);
		finish();
	}

	private void updateData() throws Exception {
		JSONObject param = new JSONObject();
		param.put("region", region);
		param.put("mac", mac);
		param.put("androidid", androidid);
		param.put("model", model);
		param.put("nettype", netType);
		param.put("appname", appname);
		param.put("rand", randkey);

		String aesString = HttpRequest.sendPost(dataurl,
												"data=" + param.toString());
		ChannelManager.clearFiles(this);
		ChannelManager.writefile(this, ChannelDatas.FILE_DATA, aesString);
		mySettings.saveSetting("rand", randkey);
	}

	public void checkUpdateData() {
		try {
			sendLoadingMessage("正在加载数据");
			updateData();
			mySettings.saveVersion(dataVer);
			mySettings.saveNetType(netType);
			sendLoadingMessage("数据加载完毕");

			Thread.sleep(500);
			loadMainActivity();
		} catch (Exception e) {
			e.printStackTrace();
			mySettings.saveVersion(0);
			sendLoadingMessage("加载数据时发生错误！");
			relogin();
		}

	}

	private void sendTipMessage(String objString) {
		Message msg = Message.obtain();
		msg.what = 0;
		msg.obj = objString;
		handler.sendMessage(msg);
	}
	private void sendSecMessage(String objString) {
		Message msg = Message.obtain();
		msg.what = 100;
		msg.obj = objString;
		handler.sendMessage(msg);
	}
	private void sendLoadingMessage(String objString) {
		Message msg = Message.obtain();
		msg.what = 3;
		msg.obj = objString;
		handler.sendMessage(msg);
	}

	private void sendMessage(int what) {
		Message msg = Message.obtain();
		msg.what = what;
		handler.sendMessage(msg);
	}

	private int getSignatrue() {
		PackageManager pm = getPackageManager();
		int sig = 0;
		try {
			sig = pm.getPackageInfo(getPackageName(),
									PackageManager.GET_SIGNATURES).signatures[0].hashCode();
		} catch (Exception e) {
		}
		return sig;
	}

	@Override
	public void onClick(View v) {
		int num = 0;
		final String sn = et_Sn.getText().toString();
		switch (v.getId()) {
			case R.id.num_0:
				num = 0;
				et_Sn.setText(sn+num);
				break;
			case R.id.num_1:
				num = 1;
				et_Sn.setText(sn+num);
				break;
			case R.id.num_2:
				num = 2;
				et_Sn.setText(sn+num);
				break;
			case R.id.num_3:
				num = 3;
				et_Sn.setText(sn+num);
				break;
			case R.id.num_4:
				num = 4;
				et_Sn.setText(sn+num);
				break;
			case R.id.num_5:
				num = 5;
				et_Sn.setText(sn+num);
				break;
			case R.id.num_6:
				num = 6;
				et_Sn.setText(sn+num);
				break;
			case R.id.num_7:
				num = 7;
				et_Sn.setText(sn+num);
				break;
			case R.id.num_8:
				num = 8;
				et_Sn.setText(sn+num);
				break;
			case R.id.num_9:
				num = 9;
				et_Sn.setText(sn+num);
				break;
			case R.id.num_del:
				if(sn.length()>0)et_Sn.setText(sn.substring(0, sn.length()-1));
				break;
			case R.id.num_OK:
				if (isInteger(sn))
					new Thread(new Runnable() {
							@Override
							public void run() {
								try {
									JSONObject param = new JSONObject();
									param.put("mac", mac);
									param.put("androidid", androidid);
									param.put("model", model);
									param.put("sn", sn);

									String m = HttpRequest.sendPost(host
																	+ "/act3.php", "act=" + param);
									sendLoadingMessage(m);
									if(m.contains("成功"))sendMessage(Play.PREPARE_LOGIN);
								} catch (Exception e) {
								}
							}
						}).start();
				break;
			default:
				break;
		}

	}

}

