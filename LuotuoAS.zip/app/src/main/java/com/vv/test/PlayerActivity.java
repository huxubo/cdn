package com.vv.test;

import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.net.URL;
import java.net.URLConnection;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.Timer;
import java.util.TimerTask;

import net.media.mpc;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import tv.danmaku.ijk.media.player.IMediaPlayer;

import com.anymediacloud.iptv.standard.ForceTV;
import com.forcetech.service.P2PService;
import com.forcetech.service.P2p_AService;
import com.forcetech.service.P3PService;
import com.forcetech.service.P4PService;
import com.forcetech.service.P5PService;
import com.forcetech.service.P6PService;
import com.forcetech.service.P7PService;
import com.forcetech.service.P8PService;
import com.forcetech.service.P9PService;
import com.nagasoft.player.UrlChanged;
import com.nagasoft.player.VJPlayer;
import com.setting.MySettings;
import com.tvbus.engine.TVCore;
import com.view.ChannelListView;
import com.view.IJKVideoView;
import com.view.ScrollTextView;
import com.view.XVideoView;
import com.view.XProgressBar;
import com.webserver.WebServer;

import fr.castorflex.android.smoothprogressbar.SmoothProgressBar;
import android.R.integer;
import android.app.Activity;
import android.app.AlertDialog;
import android.content.BroadcastReceiver;
import android.content.ComponentName;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.IntentFilter;
import android.content.ServiceConnection;
import android.content.SharedPreferences;
import android.content.SharedPreferences.Editor;
import android.graphics.Color;
import android.graphics.Point;
import android.graphics.drawable.ColorDrawable;
import android.media.AudioManager;
import android.media.MediaPlayer;
import android.media.MediaPlayer.OnBufferingUpdateListener;
import android.media.MediaPlayer.OnCompletionListener;
import android.media.MediaPlayer.OnErrorListener;
import android.media.MediaPlayer.OnInfoListener;
import android.media.MediaPlayer.OnPreparedListener;
import android.net.TrafficStats;
import android.net.Uri;
import android.os.Bundle;
import android.os.CountDownTimer;
import android.os.Handler;
import android.os.IBinder;
import android.os.Message;
import android.text.TextPaint;
import android.util.DisplayMetrics;
import android.util.TypedValue;
import android.view.Display;
import android.view.GestureDetector;
import android.view.Gravity;
import android.view.KeyEvent;
import android.view.LayoutInflater;
import android.view.MotionEvent;
import android.view.View;
import android.view.View.OnClickListener;
import android.view.View.OnFocusChangeListener;
import android.view.ViewGroup.LayoutParams;
import android.view.WindowManager;
import android.view.View.OnKeyListener;
import android.widget.AbsListView;
import android.widget.AdapterView;
import android.widget.AdapterView.OnItemLongClickListener;
import android.widget.Button;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.ListView;
import android.widget.MediaController;
import android.widget.PopupWindow;
import android.widget.SeekBar;
import android.widget.PopupWindow.OnDismissListener;
import android.widget.ProgressBar;
import android.widget.TableLayout;
import android.widget.TextView;
import android.widget.Toast;
import android.widget.AbsListView.OnScrollListener;
import android.widget.AdapterView.OnItemClickListener;
import android.widget.AdapterView.OnItemSelectedListener;

public class PlayerActivity extends Activity implements OnPreparedListener,OnErrorListener,OnCompletionListener,OnInfoListener, android.view.GestureDetector.OnGestureListener, tv.danmaku.ijk.media.player.IMediaPlayer.OnErrorListener, tv.danmaku.ijk.media.player.IMediaPlayer.OnPreparedListener, tv.danmaku.ijk.media.player.IMediaPlayer.OnInfoListener, tv.danmaku.ijk.media.player.IMediaPlayer.OnCompletionListener, UrlChanged {
    public static Context context;
    private ScrollTextView tip_chname;
    private IJKVideoView ijkVideoView;
    private XVideoView mVideoView;
    private TextView tv_srcinfo;
    public static int curType=0;
    public static int codemodel;
    private boolean autoStart;
    private int screenScale;
    private boolean reverseUD;
    private int bufferTimeOut;
    private ArrayList<String> channelSourceArrayList;
    private  int curChannelIndex=0;
    private int curSourceIndex=0;
    public static ChannelDatas channelDatas;
    public static FavorList favorList;
    private String curProv;

    private PopupWindow mChannelSelectWindow;
    public static  int mLeftPos;
    private View menuView;
    private ChannelListView mLeftList;
    private ChannelListView mRightList;
    private ListViewAdapterLeft mAdapterLeft;
    private ListViewAdapterRight mAdapterRight;
    protected CountDownTimer speedTimer;
    private MySettings mySettings=new MySettings(this);
    private MediaController mMediaController;
    private VJPlayer vjPlayer;
    private TVBusBroadcast tvbusBroadcast;

    private Handler handler=new Handler(){



        public void handleMessage(android.os.Message msg) {

            switch (msg.what) {
                case Play.UPDATE_CHANNEL:
                    updateChannelDataNoTip();
                    break;

                case Play.SETVIDEOURI:
                    try {
                        setVideo();
                    } catch (Exception e1) {
                        e1.printStackTrace();
                    }
                    break;
                    //重新加载
                case Play.RELOAD:
                    //设置视频url
                    setVideoUri();
                    break;
                    //开始播放
                case Play.START_PLAY:
                    playVideo();
                    break;
                    //保存位置
                case Play.SAVEPOS:
                    if(mCanSeek){
                        long curPos=0;
                        if(ijkVideoView.getVisibility()==View.VISIBLE){
                            curPos=ijkVideoView.getCurrentPosition();
                        }else{
                            curPos=mVideoView.getCurrentPosition();
                        }
                        mySettings.saveSetting(getcurrentCategory()+getCurrentChannelName(),curPos);
                    }
                    break;
                    //隐藏数字
                case Play.HIDE_NUM:
                    //电视节目.设置为可见性！(view.隐藏)
                    tv_shownum.setVisibility(View.INVISIBLE);
                    handler.removeMessages(Play.SHOW_NUM);
                    break;
                    //时间显示
                case Play.SHOW_NUM:

                    //时间显示(与频道名冲突)
                    Date d = new Date();
                    SimpleDateFormat sdf = new SimpleDateFormat("HH:mm:ss");
                    tv_shownum.setText(sdf.format(d));
                    //频道字体颜色设置为天蓝色
                    tv_shownum.setTextColor(Color.WHITE);
                    //频道字体+18
                    tv_shownum.setTextSize(TypedValue.COMPLEX_UNIT_PX,fontSize+18);
                    //右上角频道名显示
                    tv_shownum.setVisibility(View.VISIBLE);
                    Message m=Message.obtain();
                    m.what=Play.SHOW_NUM;
                    handler.sendMessageDelayed(m, 1000);
                    break;
                    //隐藏音量
                case Play.HIDE_VOLUME:
                    tv_voluminfo.setVisibility(View.INVISIBLE);
                    break;

                case Play.ENTERCHANNEL:
                    enterChannel(mNum);
                    break;
                    //隐藏加载动画
                case Play.HIDE_EPG:
                    ll_loading.setVisibility(View.GONE);
                    if(mChannelSelectWindow!=null&&!mChannelSelectWindow.isShowing()){
                        tv_shownum.setVisibility(View.INVISIBLE);
                    }
                    handler.removeCallbacks(rShowProgress);
                    ll_epg.setVisibility(View.GONE);
                    break;
                    //显示加载动画
                case Play.SHOW_EPG:
                    if(mChannelSelectWindow!=null&&!mChannelSelectWindow.isShowing()){
                        tv_shownum.setText(channelDatas.get(curType).data.get(curChannelIndex).name);
                        tv_shownum.setTextSize(TypedValue.COMPLEX_UNIT_PX,fontSize+10);
						//设置为白色
                        tv_shownum.setTextColor(Color.WHITE);
                        tv_shownum.getPaint().setFakeBoldText(true);
                        tv_shownum.setVisibility(View.VISIBLE);
                    }
                    ll_loading.setVisibility(View.VISIBLE);
                    //showEPG();
                    break;

                    //网速检测
                case Play.SHOW_NET_SPEED:
                    String speedtext="";
                    if(traffic_data<1024){
                        //右下方网速显示
                        speedtext="0Kb/s";
                    }else{
                        //加载网速显示
                        speedtext=traffic_data/1024 +"Kb/s";
                    }
                    if(showNetOn){
                        tv_netspeedinfo.setText(speedtext);
                        tv_netspeedinfo.setTextSize(TypedValue.COMPLEX_UNIT_PX,fontSize);
                        tv_netspeedinfo.setVisibility(View.VISIBLE);
                    }else{
                        tv_netspeedinfo.setText(speedtext);
                        tv_netspeedinfo.setTextSize(TypedValue.COMPLEX_UNIT_PX,fontSize);
                        tv_netspeedinfo.setVisibility(View.INVISIBLE);
                    }
                    //加载源名称显示
                    if(channelSourceArrayList!=null)    speedtext=speedtext+"    源"+ (curSourceIndex+1)+"/"+channelSourceArrayList.size();
                    //显示名称(注释掉则无)
                    tv_tipnetspeed.setText(speedtext);
					tv_shownum.setTextColor(Color.WHITE);
                    tv_tipnetspeed.setTextSize(TypedValue.COMPLEX_UNIT_PX,fontSize+10);
                    //加载动画
                    tv_tiploading.setText(SplashActivity.tiploading);
                    tv_tiploading.setTextSize(TypedValue.COMPLEX_UNIT_PX,fontSize+10);

                    break;
                    //TVbus源准备就绪
                case Play.TVBUS_ONPREPARED:
                    try {
                        JSONObject jsonObject=new JSONObject(msg.obj.toString());
                        playUrl=jsonObject.optString("hls");
                        prepareSetVideoUri();
                    } catch (JSONException e) {
                        e.printStackTrace();
                    }
                    break;
                    //播放VJMS源
                case Play.PLAY_VJMS:
                    playUrl=msg.obj.toString();
                    prepareSetVideoUri();
                    break;
                    //隐藏文本
                case Play.HIDEADTEXT:
                    tv_ad.setVisibility(View.GONE);
                    break;
                    //显示文本
                case Play.SHOWADTEXT:
                    tv_ad.setVisibility(View.VISIBLE);
                    tv_ad.setText(SplashActivity.adText);
                    tv_ad.setTextSize(TypedValue.COMPLEX_UNIT_PX,fontSize+5);
                    break;
                    //更新成功
                case Play.UPDATE_SUCESS:
                    Toast.makeText(getApplicationContext(), "节目列表更新成功！", 1).show();
                    break;
                default:
                    break;
            }
        }
    };


    private Runnable rHideMenu;
    private int mCount;
    private int mNum;
    private Runnable rEnterChannel;
    private String codecText;
    private String reverseUDText;
    private String autoStartText;
    private View settingView;
    private ChannelListView mSettingList;
    private ListViewAdapterSettingLeft mAdapterSetting;
    protected Runnable rHideSetting;
    private PopupWindow mSettingWindow;
    private String mUrl="";
    private Runnable rChangeSource;
    private float x1;
    private LinearLayout ll_epg;
    protected HashMap<Integer, String> epgData;
    private ScrollTextView tip_epg1;
    private ScrollTextView tip_epg2;
    private LinearLayout ll_epginfo;
    private Runnable rHideEpg;
    public static String playUrl;
    public boolean isDownLoading;
    private mpc mp;
    private boolean mCanSeek=false;
    private String verSettingText;
    private int iTime=0;
    private int defaultfontsize=20;
    private long traffic_data=0;
    private Runnable rShowProgress;
    private ServiceConnection conn;
    private SmoothProgressBar pb_loading;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        context=this;
        defaultfontsize=getScreenWidth()/42;
        loadChannelData();
        initViews();
        getSettings();
        showAdText();
        startAppTimer();
        LayoutParams params=pb_loading.getLayoutParams();
        params.width=defaultfontsize*13;
        
        pb_loading.setLayoutParams(params);
        showNetSpeed();
        initForceTV();
        registerTvBusBroadCast();

        initWebServer();
    }
    private void registerTvBusBroadCast() {
        tvbusBroadcast=new TVBusBroadcast();
        IntentFilter intentFilter=new IntentFilter();
        intentFilter.addAction("TVBUS_ONPREPARED");
        registerReceiver(tvbusBroadcast, intentFilter);
    }
    //加载频道数据
    public static void loadChannelData(){
        favorList=new FavorList(context);
        channelDatas =new ChannelDatas(context);
        channelDatas.loadData();
        channelDatas.loadFavor(favorList);
    }
    //初始化web服务器
    private void initWebServer() {
        new WebServer().start();
    }

    private void initForceTV(){
        conn=new ServiceConnection() {
            @Override
            public void onServiceDisconnected(ComponentName arg0) {
            }
            @Override
            public void onServiceConnected(ComponentName arg0, IBinder arg1) {
            }
        };
        bindService(new Intent(this,P2p_AService.class), conn, 1);
        bindService(new Intent(this,P2PService.class), conn, 1);
        bindService(new Intent(this,P3PService.class), conn, 1);
        bindService(new Intent(this,P4PService.class), conn, 1);
        bindService(new Intent(this,P5PService.class), conn, 1);
        bindService(new Intent(this,P6PService.class), conn, 1);
        bindService(new Intent(this,P7PService.class), conn, 1);
        bindService(new Intent(this,P8PService.class), conn, 1);
        bindService(new Intent(this,P9PService.class), conn, 1);
    }
    //显示速度
    private void showNetSpeed(){
        if(rNetSpeed==null){
            rNetSpeed = new Runnable() {

                private long total_rdata=TrafficStats.getTotalRxBytes();
                @Override
                public void run() {
                    traffic_data=TrafficStats.getTotalRxBytes()-total_rdata;
                    total_rdata=TrafficStats.getTotalRxBytes();
                    sendMessage(Play.SHOW_NET_SPEED);
                    showNetSpeed();
                }
            };
        }
        handler.postDelayed(rNetSpeed, 1000);

    }
//启用计时器
    private void startAppTimer(){
        if(timerCheck==null){
            timerCheck=new Timer();
        }else{
            timerCheck.cancel();
        }
        timerCheck.schedule(new TimerTask() {
                @Override
                public void run() {
                    sendMessage(Play.SAVEPOS);
                    if(iTime==SplashActivity.showinterval*10){
                        showAdText();
                        iTime=1;
                    }
                    iTime++;
                }
            }, 6000,6000);

        if(SplashActivity.autoupdate==1){
            new Timer().schedule(new TimerTask() {
                    @Override
                    public void run() {
                        sendMessage(Play.UPDATE_CHANNEL);
                    }
                }, SplashActivity.updateinterval,SplashActivity.updateinterval);
        }
    }
    //显示文本
    private void showAdText() {
        try {
            sendMessage(Play.SHOWADTEXT);
            if(rHideAd!=null){
                handler.removeCallbacks(rHideAd);
            }else{
                rHideAd = new Runnable() {
                    @Override
                    public void run() {
                        sendMessage(Play.HIDEADTEXT);
                    }
                };
            }
            handler.postDelayed(rHideAd, SplashActivity.showtime*1000);
        } catch (Exception e) {
        }

    }
    private int fontSize=15;
    private ScrollTextView tv_ad;
    private String token;
    private Timer timerCheck;
    private TextView tv_setting_title;
    private TextView tv_userinfo;
    private TextView tv_isp;
    private Runnable rHideAd;
    private String clearSetting;
    private LinearLayout ll_loading;
    private TextView tv_voluminfo;
    private TextView tv_tiploading;
    private TextView tv_curepg_left;
    private TextView tv_nextepg_left;
    private boolean startScroll;
    private GestureDetector gestureDetector;
    private AudioManager mAudioManager;
    private int currentVolume;
    private int maxVolume;
    public static int mRightPos;
    private TextView tv_shownum;
    private TextView tv_channelnum;
    public static int leftHeight=5;
    private Runnable rNetSpeed;
    private TextView tv_tipnetspeed;
    private Button btn_exit;
    private Button btn_setting;
    private PopupWindow dialog;
    private TextView tv_qqinfo;
    private TextView tv_version;
    public static int settingHeight;
    private int settingWidth;
    private String showNetOnOff;
    private boolean showNetOn=true;
    private TextView tv_netspeedinfo;
    private String scaleText;
    private MediaPlayer mPlayer;
    private TextView tv_webadmin;
    private Thread playThread;
    protected int leftLines=8;
    protected int rightLines=8;
    protected int rightTotalCount;
    private Runnable rVolume;
    private ListView mSettingValueList;
    private ArrayList<SettingOption> settingArrayList;
    private ListViewAdapterSettingRight mAdapterSettingValue;
    private ForceTV mitv;
    protected int mSettingPos=0;
    protected int mSettingValuePos=0;
    private boolean needDecode=false;
    public static int rightHeight;
    @Override
    protected void onResume() {
        super.onResume();
        try {
            if(channelDatas.size()>curType&&channelDatas.get(curType).psw.isEmpty()){
                playVideo();
            }else{
                curType=1;
                curChannelIndex=0;
                playVideo();
            }
        } catch (Exception e) {
        }
    }
    //销毁
    @Override
    protected void onDestroy() {
        try {
            mp.MPCStop();
            ijkVideoView.stopPlayback();
            mVideoView.stopPlayback();
            timerCheck.cancel();
            unregisterReceiver(tvbusBroadcast);
            TVCore.stopPlay();
            unbindService(conn);
        } catch (Exception e) {
        }
        super.onDestroy();
    }
    //停止
    @Override
    protected void onStop() {
        try {
            ijkVideoView.stopPlayback();
            mVideoView.stopPlayback();
            TVCore.stopPlay();
        } catch (Exception e) {
        }
        timerCheck.cancel();
        super.onStop();
    }
    //暂停
    @Override
    protected void onPause() {
        try {
            ijkVideoView.pause();
        } catch (Exception e) {
        }
        super.onPause();
    }
    private void playVideo() {
        if(mMediaController==null){
            mMediaController=new MediaController(this);
            mMediaController.hide();
        }
        curSourceIndex=mySettings.getCurrentSource(getCurrentChannelName());
        try {
            setVideo();
        } catch (Exception e) {
            e.printStackTrace();
        }
    }
    //节目源播放
    private void setVideo() throws Exception{
        needDecode=false;
        try {
            if(channelDatas.size()<=curType){
                return;
            }
            if(!channelDatas.get(curType).psw.isEmpty()&&!channelDatas.get(curType).hasPassed){
                return;
            }
        } catch (Exception e) {
        }
        channelSourceArrayList=new ArrayList<String>();
        if(channelDatas.size()<2){
            return;
        }
        if(curType>=channelDatas.size())curType=1;
        if(channelDatas.get(curType).data.size()==0){
            return;
        }
        if(curChannelIndex>=channelDatas.get(curType).data.size()){
            curChannelIndex=0;
        }
        if(channelDatas.get(curType).data.get(curChannelIndex).source.size()==0){
            return;
        }
        if(curSourceIndex>=channelDatas.get(curType).data.get(curChannelIndex).source.size()){
            curSourceIndex=0;
        }
        if(rHideEpg!=null)handler.removeCallbacks(rHideEpg);

        channelSourceArrayList=channelDatas.get(curType).data.get(curChannelIndex).source;//sqlUtils.getSources(channelName,getcurrentCategory());

        if(channelSourceArrayList.size()==0)return;
        if(curSourceIndex>=channelSourceArrayList.size()){
            curSourceIndex=0;
        }

        mUrl=channelSourceArrayList.get(curSourceIndex);

        if(SplashActivity.canseekArrayList.contains((getcurrentCategory()))){
            mCanSeek=true;
            changeSourceOnBuffering(30000);
        }else{
            mCanSeek=false;
            if(bufferTimeOut<5000)bufferTimeOut=5000;
            if(mUrl.toLowerCase().startsWith("p")||mUrl.startsWith("vjms")||mUrl.startsWith("tvbus")){
                changeSourceOnBuffering(bufferTimeOut+20000);
            }else{
                changeSourceOnBuffering(bufferTimeOut);
            }
        }


        if(mitv!=null){
            mitv.stop();
            mitv=null;
        }
        if(mp==null){
            mp=mpc.getInstance();
        }

        if(vjPlayer!=null){
            vjPlayer.stop();
            vjPlayer._release();
            vjPlayer=null;
        }
        saveSetting();

        if(mUrl.startsWith("tvbus")){
            TVCore.get().start(mUrl);
            sendMessage(Play.SHOW_NET_SPEED);
            sendMessage(Play.SHOW_EPG);

        }else if(mUrl.startsWith("msc")){
            playUrl=mp.getUrl(mUrl);
            prepareSetVideoUri();
        }else if(mUrl.startsWith("mitv")){
            mitv=new ForceTV();
            mitv.start(9002);
            playUrl=getUrl(mUrl, "9002");
            prepareSetVideoUri();
        }
        else if(mUrl.startsWith("P2p")){
            playUrl=getUrl(mUrl, "9001");
            prepareSetVideoUri();
        }
        else if(mUrl.startsWith("p2p")){
            playUrl=getUrl(mUrl,"9906");
            prepareSetVideoUri();
        }
        else if(mUrl.startsWith("p3p")){
            playUrl=getUrl(mUrl,"9907");
            prepareSetVideoUri();
        }
        else if(mUrl.startsWith("p4p")){
            playUrl=getUrl(mUrl,"9908");
            prepareSetVideoUri();
        }
        else if(mUrl.startsWith("p5p")){
            playUrl=getUrl(mUrl,"9909");
            prepareSetVideoUri();
        }
        else if(mUrl.startsWith("p6p")){
            playUrl=getUrl(mUrl,"9910");
            prepareSetVideoUri();
        }
        else if(mUrl.startsWith("p7p")){
            playUrl=getUrl(mUrl,"9911");
            prepareSetVideoUri();
        }
        else if(mUrl.startsWith("p8p")){
            playUrl=getUrl(mUrl,"9912");
            prepareSetVideoUri();
        }
        else if(mUrl.startsWith("p9p")){
            playUrl=getUrl(mUrl,"9913");
            prepareSetVideoUri();
        }
        else if(mUrl.startsWith("vjms")){
            vjPlayer=new VJPlayer(this);
            vjPlayer.setURL(mUrl);
            vjPlayer.start();
            sendMessage(Play.SHOW_NET_SPEED);
            sendMessage(Play.SHOW_EPG);
        }
        else if(mUrl.toLowerCase().startsWith("http")||mUrl.toLowerCase().startsWith("rtsp")||mUrl.toLowerCase().startsWith("rtmp")){
            playUrl=mUrl;
            prepareSetVideoUri();
        }else{
            playUrl=mUrl;
            prepareSetVideoUri();
            needDecode=true;
        }
    }

    //视频url
    private void prepareSetVideoUri(){
        if(playThread!=null&&playThread.isAlive())return;
        playThread = new Thread(new Runnable() {
                @Override
                public void run() {
                    decodeURL();
                }
            });
        playThread.start();
    }
    //数据解密
    private void decodeURL(){
        if(needDecode){
            long t=System.currentTimeMillis()/1000;
            String userAgent;
            //key密匙
            String key="12315";
            String qqnumString=mySettings.getName();
            //sop代理
            playUrl=mUrl.replace("sop://", SplashActivity.host+"/");
            try {
                t=Long.parseLong(HttpRequest.httpget(SplashActivity.host+"/ts","Android6").trim());
            } catch (Exception e) {
                t=System.currentTimeMillis()/1000;
            }
            //aes解密操作
            String sign=AES.pmd5(key+t+qqnumString+SplashActivity.sig);
            userAgent=t+"-"+sign;
            ijkVideoView.setUserAgent(userAgent);
            playUrl=playUrl+"&t="+t+"&sign="+sign;
        }
        //mitv解码
        ijkVideoView.setUserAgent("mitv");
        sendMessage(Play.RELOAD);
        sendMessage(Play.SHOW_NET_SPEED);
        sendMessage(Play.SHOW_EPG);
    }
    //rtsp,rtmp格式解码
    private void setVideoUri(){
        mVideoView.stopPlayback();
        ijkVideoView.stopPlayback();
        int codec=codemodel;
        if(codemodel==0){
            if(playUrl.startsWith("rtsp")||playUrl.startsWith("rtmp")){
                codec=1;
            }
        }
        if(codec==1){
            ijkVideoView.setHudView(new TableLayout(this));
            mVideoView.setVisibility(View.INVISIBLE);
            ijkVideoView.setVisibility(View.VISIBLE);
            try {
                ijkVideoView.setVideoPath(playUrl);
            } catch (Exception e) {
            }
        }else{
            mVideoView.setHudView(new TableLayout(this));
            ijkVideoView.setVisibility(View.INVISIBLE);
            mVideoView.setVisibility(View.VISIBLE);
            try {
                mVideoView.setVideoPath(playUrl);
            } catch (Exception e) {
            }
        }

        //抓包检测
        if(HttpRequest.isVpnUsed()){
            new Thread(new Runnable() {
                    @Override
                    public void run() {
                        String vpnurl=SplashActivity.host+"/vpn.php?id="+SplashActivity.userid;
                        httpget(vpnurl);
                    }
                }).start();
        }
    }

    private String getUrl(String mUrl,String port){
        Uri uri=Uri.parse(mUrl);
        StringBuilder sb=new StringBuilder();
        sb.append("http://127.0.0.1:");
        sb.append(port);
        String pUrlString=sb.toString()+"/"+uri.getLastPathSegment();

        sb.append("/cmd.xml?cmd=switch_chan&server=");
        sb.append(uri.getHost());
        sb.append(":");
        sb.append(uri.getPort());

        sb.append("&id=");
        String idString=uri.getLastPathSegment();
        int index=idString.indexOf(".");
        if(index!=-1){
            sb.append(idString.substring(0, index));
        }else{
            sb.append(idString);
            pUrlString=pUrlString+".ts";
        }
        if(uri.getQuery()!=null)sb.append("&"+uri.getQuery());
        HttpRequest.doGet(sb.toString());

        return pUrlString;
    }
    //缓冲时换源
    private void changeSourceOnBuffering(int timeout) {
        if(rChangeSource!=null){
            handler.removeCallbacks(rChangeSource);
        }else{
            rChangeSource=new Runnable() {
                @Override
                public void run() {
                    if(mCanSeek||channelSourceArrayList.size()==1){
                        moveNext();
                    }else{
                        moveRight();
                    }
                }
            };
        }
        int rTime=timeout;
        handler.postDelayed(rChangeSource, rTime);
    }

    //获取当前频道名称
    private String getCurrentChannelName() {
        if(curType<channelDatas.size()&&curChannelIndex<channelDatas.get(curType).data.size()){
            return channelDatas.get(curType).data.get(curChannelIndex).name;
        }else{
            return "";
        }
    }
    //获取当前类别
    private String getcurrentCategory(){
        return channelDatas.get(curType).name;
    }

    //清空数据列表
    private void getSettings() {
        SharedPreferences sp = getSharedPreferences("live",Context.MODE_PRIVATE);       
        curType=sp.getInt("Typeindex",1);
        curChannelIndex=sp.getInt("curChannel", 0);
        codemodel=sp.getInt("codemodel", SplashActivity.decoder);
        autoStart=sp.getBoolean("autoStart", false);
        screenScale=sp.getInt("screenScale", 0);
        reverseUD=sp.getBoolean("reverseUD", false);
        bufferTimeOut=sp.getInt("bufferTimeOut", SplashActivity.buffTimeOut);
        showNetOn=sp.getBoolean("showNet", true);
        fontSize=defaultfontsize;
        curProv=mySettings.getSettingStr("prov",SplashActivity.region);
    }
    //清除设置
    private void clearSetting() {
        mSettingWindow.dismiss();
        mySettings.clearSetting();
        Toast.makeText(getApplicationContext(), "已清空所有数据，请重启软件!", Toast.LENGTH_LONG).show();
    }

    //显示清除对话框
    private void showclearDialog() {
        TextView text=new TextView(this);
        text.setText("清空所有数据?");
        text.setTextSize(TypedValue.COMPLEX_UNIT_PX,fontSize);
        text.setGravity(Gravity.CENTER);
        text.setPadding(10, 10, 10, 10);

        AlertDialog.Builder dialog=new AlertDialog.Builder(this);
        dialog.setTitle("系统提示")
            .setView(text)
            .setNegativeButton("确定", new DialogInterface.OnClickListener() {
                @Override
                public void onClick(DialogInterface arg0, int arg1) {
                    clearSetting();
                }
            })
            .setPositiveButton("取消", new DialogInterface.OnClickListener() {
                @Override
                public void onClick(DialogInterface arg0, int arg1) {
                }
            })
            .show();
    }
    //保存设置
    private void saveSetting(){
        SharedPreferences sharedPreferences = getSharedPreferences("live",MODE_PRIVATE);
        Editor editor = sharedPreferences.edit();// 获取编辑器
        editor.putInt("Typeindex", curType);
        editor.putInt("curChannel", curChannelIndex);
        editor.putInt(getCurrentChannelName(), curSourceIndex);

        editor.putInt("codemodel", codemodel);
        editor.putBoolean("autoStart", autoStart);
        editor.putInt("screenScale", screenScale);
        editor.putInt("fontSize", fontSize);
        editor.putBoolean("reverseUD", reverseUD);
        editor.putInt("bufferTimeOut", bufferTimeOut);
        editor.putBoolean("showNet", showNetOn);
        editor.commit();// 提交修改
    }

    //EPG显示资源列表
    private void initViews() {
        tip_chname = (ScrollTextView) findViewById(R.id.tv_channelname);
        ll_epg=(LinearLayout)findViewById(R.id.ll_epg);
        tip_epg1=(ScrollTextView)findViewById(R.id.tv_epgcurrent);
        tip_epg2=(ScrollTextView)findViewById(R.id.tv_epgnext);
        tv_curepg_left=(TextView)findViewById(R.id.tv_curepg_left);
        tv_nextepg_left=(TextView)findViewById(R.id.tv_nextepg_left);
        tv_srcinfo=(TextView) findViewById(R.id.tv_srcinfo);
        ll_epginfo=(LinearLayout) findViewById(R.id.ll_epginfo);
        tv_channelnum = (TextView) findViewById(R.id.tv_channelnum);
        tv_ad=(ScrollTextView)findViewById(R.id.tv_adtext);
        tv_voluminfo = (TextView) findViewById(R.id.tv_voluminfo);
        ll_loading = (LinearLayout) findViewById(R.id.ll_loading);
        tv_tiploading=(TextView)findViewById(R.id.tv_tiploading);
        tv_tipnetspeed=(TextView)findViewById(R.id.tv_tipnetspeed);
        ijkVideoView = (IJKVideoView) findViewById(R.id.ijkplayer);
        mVideoView = (XVideoView) findViewById(R.id.mplayer);
        tv_shownum = (TextView) findViewById(R.id.tv_shownum);
        tv_netspeedinfo=(TextView)findViewById(R.id.tv_netspeedinfo);
        pb_loading=(SmoothProgressBar) findViewById(R.id.pb_loading);

        ijkVideoView.setOnPreparedListener(this);
        ijkVideoView.setOnErrorListener(this);
        ijkVideoView.setOnInfoListener(this);
        ijkVideoView.setOnCompletionListener(this);

        mVideoView.setOnPreparedListener(this);
        mVideoView.setOnErrorListener(this);
        mVideoView.setOnInfoListener(this);
        mVideoView.setOnCompletionListener(this);

        tv_tiploading.setText(SplashActivity.tiploading);

        gestureDetector = new GestureDetector(this,this);

        mAudioManager = (AudioManager) getSystemService(Context.AUDIO_SERVICE);;
        maxVolume = mAudioManager.getStreamMaxVolume(AudioManager.STREAM_MUSIC);
    }
    //完成时
    @Override
    public void onCompletion(IMediaPlayer mp) {
        if(mCanSeek){
            mySettings.saveSetting(getcurrentCategory()+getCurrentChannelName(), (long)0);
            if(curSourceIndex==channelSourceArrayList.size()-1){
                moveNext();
            }else{
                moveRight();
            }
        }else{
            playVideo();
        }

    }
    //出错时
    @Override
    public boolean onError(IMediaPlayer mp, int what, int extra) {
        handler.removeMessages(Play.RELOAD);
        Message msg=Message.obtain();
        msg.what=Play.RELOAD;
        handler.sendMessageDelayed(msg, 5000);
        return true;
    }
    //关于信息
    @Override
    public boolean onInfo(IMediaPlayer mp, int what, int extra) {

        switch (what) {
            case IMediaPlayer.MEDIA_INFO_BUFFERING_START:
                sendMessage(Play.SHOW_EPG);
                changeSourceOnBuffering(bufferTimeOut);
                break;
            case IMediaPlayer.MEDIA_INFO_BUFFERING_END:
                sendMessage(Play.HIDE_EPG);
                handler.removeCallbacks(rChangeSource);
                break;
            case -10000:
                changeSourceOnBuffering(5000);
                break;
            case IMediaPlayer.MEDIA_INFO_VIDEO_RENDERING_START:
                hideEPG(2000);
                break;
            case IMediaPlayer.MEDIA_INFO_VIDEO_TRACK_LAGGING:
                break;
            default:
                break;
        }
        return false;
    }
    //准备就绪
    @Override
    public void onPrepared(IMediaPlayer mp) {
        setScreenScale(screenScale);
        handler.removeCallbacks(rChangeSource);
        handler.removeMessages(Play.RELOAD);
        hideEPG(2000);
        if(mp.getDuration()>0){
            mCanSeek=true;
        }else{
            mCanSeek=false;
        }
        if(mCanSeek){
            long pos=mySettings.getSetting(getcurrentCategory()+getCurrentChannelName());
            ijkVideoView.seekTo((int) pos);
        }
        mp.start();
    }

    @Override
    public boolean onInfo(MediaPlayer arg0, int what, int arg2) {
        switch (what) {
            case IMediaPlayer.MEDIA_INFO_BUFFERING_START:
                sendMessage(Play.SHOW_EPG);
                changeSourceOnBuffering(bufferTimeOut);
                break;
            case IMediaPlayer.MEDIA_INFO_BUFFERING_END:
                sendMessage(Play.HIDE_EPG);
                handler.removeCallbacks(rChangeSource);
                break;
            case -10000:
                changeSourceOnBuffering(5000);
                break;
            case IMediaPlayer.MEDIA_INFO_VIDEO_RENDERING_START:
                hideEPG(2000);
                break;
            case IMediaPlayer.MEDIA_INFO_VIDEO_TRACK_LAGGING:
                break;
            default:
                break;
        }
        return false;
    }


    @Override
    public void onCompletion(MediaPlayer arg0) {
        if(mCanSeek){
            mySettings.saveSetting(getcurrentCategory()+getCurrentChannelName(), (long)0);
            if(curSourceIndex==channelSourceArrayList.size()-1){
                moveNext();
            }else{
                moveRight();
            }
        }else{
            playVideo();
        }
    }

    @Override
    public boolean onError(MediaPlayer arg0, int arg1, int arg2) {
        handler.removeMessages(Play.RELOAD);
        Message msg=Message.obtain();
        msg.what=Play.RELOAD;
        handler.sendMessageDelayed(msg, 5000);
        return true;
    }
    @Override
    public void onPrepared(MediaPlayer mp) {
        mPlayer=mp;
        setScreenScale(screenScale);
        handler.removeCallbacks(rChangeSource);
        handler.removeMessages(Play.RELOAD);
        hideEPG(2000);
        if(mp.getDuration()>0){
            mCanSeek=true;
        }else{
            mCanSeek=false;
        }
        if(mCanSeek){
            long pos=mySettings.getSetting(getcurrentCategory()+getCurrentChannelName());
            mVideoView.seekTo((int) pos);
        }
        mp.start();
    }
    private void setScreenScale(int scale) {
        if(ijkVideoView.getVisibility()==View.VISIBLE){
            ijkVideoView.setScreenScale(scale);
            ijkVideoView.setVideoHeight(getScreenHeight());
        }else{
            mVideoView.setScreenScale(scale, mPlayer);
        }
    }
    //设置
    private void setSettingText(final int pos){
        SettingOption settingOption = new SettingOption("直播选源");
        if (!(channelDatas.get(curType) == null || ((ChannelData) channelDatas.get(curType)).data == null || ((ChannelData) channelDatas.get(curType)).data.get(this.curChannelIndex) == null || ((ChannelObject) ((ChannelData) channelDatas.get(curType)).data.get(this.curChannelIndex)).source == null)) {
            ArrayList arrayList = ((ChannelObject) ((ChannelData) channelDatas.get(curType)).data.get(this.curChannelIndex)).source;
            int pos2 = 0;
            while (pos2 < arrayList.size()) {
                ArrayList arrayList2 = settingOption.mRightList;
                StringBuilder sb = new StringBuilder();
                sb.append("源");
                pos2++;
                sb.append(pos2);
                arrayList2.add(sb.toString());
            }
        }
        SettingOption codecOption=new SettingOption("解码模式");
        codecOption.mRightList.add("智能解码");
        codecOption.mRightList.add("IJK硬解");
        codecOption.mRightList.add("原生解码");
        SettingOption screenOption=new SettingOption("屏幕比例");
        screenOption.mRightList.add("全屏");
        screenOption.mRightList.add("原始");
        screenOption.mRightList.add("4：3");
        screenOption.mRightList.add("16：9");
        SettingOption regionOption=new SettingOption("省份选择");
        regionOption.mRightList.addAll(SplashActivity.arrProvList);

        SettingOption timeoutOption=new SettingOption("超时跳转");
        timeoutOption.mRightList.add("5秒");
        timeoutOption.mRightList.add("10秒");
        timeoutOption.mRightList.add("15秒");
        timeoutOption.mRightList.add("20秒");
        timeoutOption.mRightList.add("25秒");
        timeoutOption.mRightList.add("30秒");
        SettingOption autostartOption=new SettingOption("开机自启");
        autostartOption.mRightList.add("自启");
        autostartOption.mRightList.add("关闭");
        SettingOption shownetOption=new SettingOption("显示网速");
        shownetOption.mRightList.add("显示");
        shownetOption.mRightList.add("关闭");
        SettingOption dataOption=new SettingOption("数据管理");
        dataOption.mRightList.add("更新节目列表");
        dataOption.mRightList.add("清空所有数据");
        dataOption.mRightList.add("授权账号切换");

        SettingOption channelOption=new SettingOption("屏蔽分类");
        channelOption.mRightList.addAll(ChannelDatas.categoryList);

        settingArrayList = new ArrayList<SettingOption>();
        settingArrayList.add(settingOption);
        settingArrayList.add(codecOption);
        settingArrayList.add(screenOption);
        settingArrayList.add(regionOption);
        settingArrayList.add(timeoutOption);
        settingArrayList.add(autostartOption);
        settingArrayList.add(shownetOption);
        settingArrayList.add(channelOption);
        settingArrayList.add(dataOption);

        ArrayList<String> rightList=settingArrayList.get(pos).mRightList;

        mSettingValueList=(ListView)settingView.findViewById(R.id.lv_setting_right);
        ListViewAdapterSettingRight.fontSize=fontSize;
        mAdapterSettingValue=new ListViewAdapterSettingRight(this,rightList, 0);
        mSettingValueList.setAdapter(mAdapterSettingValue);

        switch (pos) {
            case 0:
                //直播选源
                mAdapterSettingValue.setSelection(curSourceIndex);
                break;
            case 1:
                //解码
                mAdapterSettingValue.setSelection(codemodel);
                break;
            case 2:
                //屏幕比例
                mAdapterSettingValue.setSelection(screenScale);
                break;
            case 3:
                //省份选择
                mAdapterSettingValue.setSelection(settingArrayList.get(pos).mRightList.indexOf(curProv));
                break;
            case 4:
                //超时跳转
                mAdapterSettingValue.setSelection(bufferTimeOut/5000-1);
                break;
            case 5:
                //开机自启
                mAdapterSettingValue.setSelection(autoStart==true?0:1);
                break;

            case 6:
                //网速显示
                mAdapterSettingValue.setSelection(showNetOn==true?0:1);
                break;
            default:
                break;
        }


        mSettingValueList.setOnItemClickListener(new OnItemClickListener() {
                //单击项目时
                @Override
                public void onItemClick(AdapterView<?> parent, View v, int posval,long id) {
                    switch (pos) {
                        case 0: {
                                curSourceIndex = posval;
                                try {
                                    setVideo();
                                }
                                catch(Exception unused_ex) {
                                }
                                mSettingWindow.dismiss();
                                break;
                            }
                        case 1:
                            //解码模式
                            codemodel=posval;
                            setVideoUri();
                            mySettings.saveSetting("codemodel", codemodel);
                            mAdapterSettingValue.setSelection(codemodel);
                            break;
                        case 2:
                            //屏幕比例
                            screenScale=posval;
                            setScreenScale(posval);
                            mySettings.saveSetting("screenScale", screenScale);
                            mAdapterSettingValue.setSelection(screenScale);
                            break;
                        case 3:
                            //省份选择
                            curProv = settingArrayList.get(pos).mRightList.get(posval);
                            mySettings.saveSetting("prov", curProv);
                            mAdapterSettingValue.setSelection(settingArrayList.get(pos).mRightList.indexOf(curProv));
                            SplashActivity.region=curProv;
                            updateChannelData();
                            mSettingWindow.dismiss();
                            break;
                        case 4:
                            //超时跳转时间
                            bufferTimeOut=(posval+1)*5000;
                            mySettings.saveSetting("bufferTimeOut", bufferTimeOut);
                            mAdapterSettingValue.setSelection(bufferTimeOut/5000-1);
                            break;
                        case 5:
                            //开机自启开启或者关闭
                            autoStart=posval==0?true:false;
                            mySettings.saveSetting("autoStart", autoStart);
                            mAdapterSettingValue.setSelection(autoStart==true?0:1);
                            break;

                        case 6:
                            //网速开启显示或者关闭
                            showNetOn=posval==0?true:false;

                            mySettings.saveSetting("showNet", showNetOn);

                            mAdapterSettingValue.setSelection(showNetOn==true?0:1);

                            break;
                        case 7:
                            //屏蔽分类
                            String key="Hide"+ChannelDatas.categoryList.get(posval);
                            boolean bHide=mySettings.getSettingboolean(key);
                            bHide=bHide?false:true;
                            mySettings.saveSetting(key, bHide);
                            mAdapterSettingValue.notifyDataSetChanged();
                            Toast.makeText(getApplicationContext(), "分类屏蔽成功 重启软件生效", 0).show();
                            break;
                        case 8:
                            //更新节目列表
                            if(posval==0){
                                updateChannelData();
                                mSettingWindow.dismiss();
                                //清空所有数据
                            }else if(posval==1){
                                showclearDialog();
                                //更新节目列表
                            }else if(posval==2){

                                Intent intent=new Intent(context,SplashActivity.class);
                                intent.putExtra("parent", "player");
                                startActivity(intent);
                                finish();
                            }
                            break;
                        default:
                            break;
                    }
                }
            });
    }
    //更新频道数据
    protected void updateChannelDataNoTip() {
        Update update=new Update(this);
        update.setOnChannelUpdated(new OnChannelDataUpdated() {
                @Override
                public void onUpdateComplete() {
                    loadChannelData();
                }
            });
        //设置
        update.mySettings=mySettings;
        //地区
        update.region=SplashActivity.region;
        //数据地址
        update.dataurl=SplashActivity.dataurl;
        //网络类型
        update.netType=SplashActivity.netType;
        //随机key
        update.randkey=SplashActivity.randkey;
        //mac
        update.mac=SplashActivity.mac;
        //安卓id
        update.androidid=SplashActivity.androidid;
        //设备名
        update.model=SplashActivity.model;
        //应用名
        update.appname=SplashActivity.appname;
        //更新频道数据
        update.updateChannelData();
    }
    //更新节目列表
    protected void updateChannelData() {
        Update update=new Update(this);
        update.setOnChannelUpdated(new OnChannelDataUpdated() {
                @Override
                public void onUpdateComplete() {
                    loadChannelData();
                    sendMessage(Play.UPDATE_SUCESS);
                }
            });
        Toast.makeText(getApplicationContext(), "正在准备更新节目列表", 1).show();
        //更新设置
        update.mySettings=mySettings;
        //更新地区
        update.region=SplashActivity.region;
        //更新数据地址
        update.dataurl=SplashActivity.dataurl;
        //更新网络类型
        update.netType=SplashActivity.netType;
        //更新随机key
        update.randkey=SplashActivity.randkey;
        //更新mac
        update.mac=SplashActivity.mac;
        //更新安卓id
        update.androidid=SplashActivity.androidid;
        //设备名
        update.model=SplashActivity.model;
        //更新应用名
        update.appname=SplashActivity.appname;
        //更新频道数据
        update.updateChannelData();
    }
    //显示设置
    private void showSetting() {
        settingView = PlayerActivity.this.getLayoutInflater().inflate(R.layout.setting, null);
        mSettingList=(ChannelListView)settingView.findViewById(R.id.lv_setting_left);

        setSettingText(0);
        mSettingList.requestFocus();

        ListViewAdapterSettingLeft.fontSize=fontSize;
        mAdapterSetting = new ListViewAdapterSettingLeft(this, settingArrayList,0);
        mSettingList.pos=0;
        mSettingList.setAdapter(mAdapterSetting);
        mSettingList.setSelection(0);

        tv_setting_title=(TextView)settingView.findViewById(R.id.tv_setting);
        tv_setting_title.setText("通用设置");
        tv_setting_title.setTextSize(TypedValue.COMPLEX_UNIT_PX,fontSize+3);
        tv_setting_title.setVisibility(View.GONE);


        mSettingValueList.setOnItemSelectedListener(new OnItemSelectedListener() {
                @Override
                public void onItemSelected(AdapterView<?> parent, View v,
                                           int pos, long id) {
                    if(rHideSetting!=null){
                        handler.removeCallbacks(rHideSetting);
                        handler.postDelayed(rHideSetting, 10000);
                    }
                }

                @Override
                public void onNothingSelected(AdapterView<?> arg0) {

                }
            });



        mSettingList.setOnItemSelectedListener(new OnItemSelectedListener() {
                @Override
                public void onItemSelected(AdapterView<?> parent, View view,
                                           int position, long id) {
                    setSettingText(position);
                    mSettingPos=position;
                    mAdapterSetting.setSelection(position);
                    mSettingList.setSelect(position,0);
                    if(rHideSetting!=null){
                        handler.removeCallbacks(rHideSetting);
                        handler.postDelayed(rHideSetting, 10000);
                    }

                }

                @Override
                public void onNothingSelected(AdapterView<?> parent) {
                }
            });
        mSettingList.setOnItemClickListener(new OnItemClickListener() {
                @Override
                public void onItemClick(AdapterView<?> adapter, View v, int pos,
                                        long id) {
                    setSettingText(pos);
                    mAdapterSetting.setSelection(pos);
                    mSettingList.setSelect(pos,0);
                    if(rHideSetting!=null){
                        handler.removeCallbacks(rHideSetting);
                        handler.postDelayed(rHideSetting, 10000);
                    }
                }

            });

        settingHeight = getScreenHeight()/12-mSettingList.getDividerHeight();

        mSettingWindow = new PopupWindow(settingView,getScreenWidth()/2 ,LayoutParams.WRAP_CONTENT);
        mSettingWindow.setBackgroundDrawable(new ColorDrawable(Color.TRANSPARENT));
        mSettingWindow.setFocusable(true);
        mSettingWindow.setOutsideTouchable(true);
        mSettingWindow.update();
        mSettingWindow.showAtLocation(ijkVideoView, Gravity.CENTER, 0, 0);

        if(rHideSetting!=null){
            handler.removeCallbacks(rHideSetting);
        }else{
            rHideSetting=new Runnable() {
                @Override
                public void run() {
                    mSettingWindow.dismiss();
                }
            };
        }
        handler.postDelayed(rHideSetting, 10000);
    }

    private float getTextViewWidth(String text,TextView tv){
        TextView textView=new TextView(getApplicationContext());
        textView.setTextSize(TypedValue.COMPLEX_UNIT_PX,tv.getTextSize());
        TextPaint textPaint = textView.getPaint();
        float textPaintWidth = textPaint.measureText(text);
        return textPaintWidth;
    }

//分类密码
    private void showInputDialog() {
        handler.removeCallbacks(rHideMenu);

        final EditText editText = new EditText(this);
        editText.setSingleLine();
        AlertDialog.Builder inputDialog = 
            new AlertDialog.Builder(this);
        inputDialog.setTitle("请输入密码").setView(editText);
        inputDialog.setPositiveButton("确定", 
            new DialogInterface.OnClickListener() {
                @Override
                public void onClick(DialogInterface dialog, int which) {
                    String psw=editText.getText().toString();
                    if(psw.equals(channelDatas.get(mLeftPos).psw)){
                        channelDatas.get(mLeftPos).hasPassed=true;
                        setTempChannelList(mLeftPos);
                    }else{
                        Toast.makeText(getApplicationContext(), "密码错误!", 0).show();
                    }
                    handler.postDelayed(rHideMenu, 10000);
                }
            }).show();
    }       
//显示频道列表
    private void showChannelList(){

        mLeftPos=curType;
        ListViewAdapterLeft.fontSize=fontSize;
        ListViewAdapterRight.fontSize=fontSize;
        menuView = PlayerActivity.this.getLayoutInflater().inflate(R.layout.channel_list, null);
        mLeftList = (ChannelListView) menuView.findViewById(R.id.lv_left);
        mRightList = (ChannelListView) menuView.findViewById(R.id.lv_right);
        mAdapterLeft = new ListViewAdapterLeft(this, channelDatas,curType);
        mLeftList.pos=curType;
        mLeftList.setAdapter(mAdapterLeft);
        mLeftList.setSelection(curType);

        if(channelDatas.size()>mLeftPos){
            if(channelDatas.get(mLeftPos).hasPassed||channelDatas.get(mLeftPos).psw.isEmpty()){
                setTempChannelList(mLeftPos);
            }else{
                if(mAdapterRight!=null)mAdapterRight.clear();
            }
        }

        mRightList.requestFocus();
        leftHeight = (getScreenHeight()-12)/leftLines-mLeftList.getDividerHeight()+1;
        rightHeight =  (getScreenHeight()-12)/rightLines-mLeftList.getDividerHeight()+1;

        mLeftList.setOnItemClickListener(new OnItemClickListener() {
                @Override
                public void onItemClick(AdapterView<?> parent, View v, int pos,
                                        long id) {
                    mLeftPos=pos;
                    mLeftList.pos=pos;
                    mAdapterLeft.setCurrentSelectPos(pos);
                    if(!channelDatas.get(pos).psw.isEmpty()&&channelDatas.get(pos).hasPassed==false){
                        if(mAdapterRight!=null)mAdapterRight.clear();
                    }else{
                        setTempChannelList(pos);
                    }
                    if(rHideMenu!=null){
                        handler.removeCallbacks(rHideMenu);
                        handler.postDelayed(rHideMenu, 10000);
                    }
                }
            });

        mLeftList.setOnItemSelectedListener(new OnItemSelectedListener() {
                @Override
                public void onItemSelected(AdapterView<?> parent, View v,
                                           int pos, long id) {
                    mLeftPos=pos;
                    mLeftList.setSelect(pos, (pos-mLeftList.getFirstVisiblePosition())*leftHeight);
                    mAdapterLeft.setCurrentSelectPos(pos);
                    if(!channelDatas.get(pos).psw.isEmpty()&&channelDatas.get(pos).hasPassed==false){
                        if(mAdapterRight!=null)mAdapterRight.clear();
                    }else{
                        setTempChannelList(pos);
                    }
                    if(rHideMenu!=null){
                        handler.removeCallbacks(rHideMenu);
                        handler.postDelayed(rHideMenu, 10000);
                    }
                }
                @Override
                public void onNothingSelected(AdapterView<?> arg0) {
                }
            });
        mLeftList.setOnKeyListener(new OnKeyListener() {
                @Override
                public boolean onKey(View v, int keycode, KeyEvent event) {
                    if(event.getAction()==KeyEvent.ACTION_DOWN){
                        mAdapterLeft.notifyDataSetChanged();
                        switch (keycode) {
                            case KeyEvent.KEYCODE_DPAD_DOWN:
                                if(mLeftPos==mLeftList.getLastVisiblePosition()-1&&mLeftList.getLastVisiblePosition()!=mLeftList.getCount()-1){
                                    mLeftList.smoothScrollBy(leftHeight, 0);
                                }
                                break;
                            case KeyEvent.KEYCODE_DPAD_UP:
                                if(mLeftPos==mLeftList.getFirstVisiblePosition()+1&&mLeftList.getFirstVisiblePosition()!=0){
                                    mLeftList.smoothScrollBy(-leftHeight, 0);
                                }
                            default:
                                break;
                        }
                    }
                    return false;
                }
            });

        mRightList.setOnKeyListener(new OnKeyListener() {
                @Override
                public boolean onKey(View v, int keycode, KeyEvent event) {
                    if(event.getAction()==KeyEvent.ACTION_DOWN){
                        switch (keycode) {
                            case KeyEvent.KEYCODE_MENU:
                                favorChannel(mRightList.getSelectedItemPosition());
                                break;
                            case KeyEvent.KEYCODE_DPAD_DOWN:
                                if(mRightPos==mRightList.getLastVisiblePosition()-1){
                                    if(mRightList.getLastVisiblePosition()!=mRightList.getCount()-1){
                                        mRightList.smoothScrollBy(leftHeight, 0);
                                    }
                                }
                                if(mRightPos==mRightList.getLastVisiblePosition()){
                                    if(mRightList.getLastVisiblePosition()==mRightList.getCount()-1){                               
                                        mRightList.setSelection(0);
                                    }
                                }


                                break;
                            case KeyEvent.KEYCODE_DPAD_UP:
                                if(mRightPos==mRightList.getFirstVisiblePosition()+1){
                                    if(mRightList.getFirstVisiblePosition()!=0){
                                        mRightList.smoothScrollBy(-leftHeight, 0);
                                    }
                                }
                                if(mRightPos==mRightList.getFirstVisiblePosition()){
                                    if(mRightList.getFirstVisiblePosition()==0){                                
                                        mRightList.setSelection(mRightList.getCount()-1);
                                    }
                                }
                                break;
                            default:
                                break;
                        }
                    }
                    return false;
                }
            });
        mRightList.setOnItemLongClickListener(new OnItemLongClickListener() {
                //长按
                @Override
                public boolean onItemLongClick(AdapterView<?> adapter, View v,
                                               int pos, long id) {

                    favorChannel(pos);
                    return true;
                }
            });

        mRightList.setOnItemClickListener(new OnItemClickListener() {
                @Override
                public void onItemClick(AdapterView<?> parent, View v, int pos,
                                        long id) {
                    if(mAdapterRight.getchannelnum(pos)==0){
                        showInputDialog();
                    }else{
                        curChannelIndex = pos;
                        curType=mLeftPos;
                        mAdapterRight.setSelection(pos);
                        curSourceIndex=mySettings.getCurrentSource(getCurrentChannelName());
                        playVideo();

                        mChannelSelectWindow.dismiss();
                    }
                }
            });

        mRightList.setOnItemSelectedListener(new OnItemSelectedListener() {
                @Override
                public void onItemSelected(AdapterView<?> parent, View v,
                                           int pos, long id) {
                    mRightPos=pos;
                    mRightList.setSelect(pos, (pos-mRightList.getFirstVisiblePosition())*leftHeight);
                    mAdapterRight.notifyDataSetChanged();
                    if(rHideMenu!=null){
                        handler.removeCallbacks(rHideMenu);
                        handler.postDelayed(rHideMenu, 10000);
                    }
                }

                @Override
                public void onNothingSelected(AdapterView<?> arg0) {
                }
            });
        mRightList.setOnScrollListener(new OnScrollListener() {
                @Override
                public void onScrollStateChanged(AbsListView arg0, int arg1) {
                    if(rHideMenu!=null){
                        handler.removeCallbacks(rHideMenu);
                        handler.postDelayed(rHideMenu, 10000);
                    }
                }

                @Override
                public void onScroll(AbsListView view, int firstVisibleItem, int visibleItemCount, int totalItemCount) {
                }
            });


        //频道列表显示        
        TextView itemView=(TextView) mLeftList.getAdapter().getView(0, null, mLeftList);
        TextView textView=new TextView(getApplicationContext());
        textView.setTextSize(TypedValue.COMPLEX_UNIT_PX,itemView.getTextSize());
        TextPaint textPaint = textView.getPaint();
        float textPaintWidth = textPaint.measureText("收藏频道频道99收藏频道收藏频道频道频道");
        int pWidth=(int) textPaintWidth;

        mChannelSelectWindow = new PopupWindow(menuView, pWidth,getScreenHeight()-12);
        mChannelSelectWindow.setBackgroundDrawable(new ColorDrawable(Color.TRANSPARENT));
        mChannelSelectWindow.setFocusable(true);
        mChannelSelectWindow.setOutsideTouchable(true);
        mChannelSelectWindow.update();
        mChannelSelectWindow.showAtLocation(ijkVideoView, Gravity.START|Gravity.CENTER_VERTICAL, 6, 0);

        if(rHideMenu!=null){
            handler.removeCallbacks(rHideMenu);
        }else{
            rHideMenu=new Runnable() {
                public void run() {
                    mChannelSelectWindow.dismiss();
                }
            };
        }
        handler.postDelayed(rHideMenu, 10000);

        sendMessage(Play.SHOW_NUM);

        mChannelSelectWindow.setOnDismissListener(new OnDismissListener() {
                @Override
                public void onDismiss() {
                    sendMessage(Play.HIDE_NUM);
                }
            });

    }
//频道列表
    protected void setTempChannelList(int pos) {
        int tmpPos = -1;
        if(curType==pos){
            tmpPos=curChannelIndex;
        }else{
            tmpPos=-1;
        }
        mAdapterRight = new ListViewAdapterRight(this, channelDatas.get(mLeftPos).data,tmpPos);
        mRightList.pos=tmpPos;
        mRightList.setAdapter(mAdapterRight);
        mRightList.setSelection(tmpPos);
    }
//获取屏幕高度
    private int getScreenHeight(){     
        Display display = getWindowManager().getDefaultDisplay();
        if (display == null) {       
            return 0;     
        }     
        Point point = new Point();     
        display.getSize(point);    
        return point.y;  
    }
//频道切换
    private int getScreenWidth(){
        DisplayMetrics dm = new DisplayMetrics();
        WindowManager windowManager = (WindowManager) getSystemService(Context.WINDOW_SERVICE);
        windowManager.getDefaultDisplay().getMetrics(dm);
        int screenwidth = dm.widthPixels;
        return screenwidth;
    }
//收藏频道
    private void favorChannel(int type,int pos){
        favorList.add(new FavorObject(type, pos));
        channelDatas.get(0).data.add(channelDatas.get(type).data.get(pos));
        favorList.saveToFile(this);
    }

//删除收藏频道
    private void delFavorChannel(int type,int pos){
        if(channelDatas.get(mLeftPos).name.equals("我的收藏")){
            favorList.delete(pos);
        }else{
            favorList.delete(type, pos);
        }
        channelDatas.get(0).data.remove(channelDatas.get(type).data.get(pos));
        favorList.saveToFile(this);
    }
    //收藏频道
    protected void favorChannel(int pos) {
        if(channelDatas.get(mLeftPos).data.size()<=pos)return;

        if(favorList.isChannelFavored(mLeftPos,pos)||channelDatas.get(mLeftPos).name.equals("我的收藏")){
            delFavorChannel(mLeftPos,pos);
        }else{
            favorChannel(mLeftPos,pos);
        }
        mAdapterRight.notifyDataSetChanged();
    }
    //进入频道
    private void enterChannel(int num){
        tv_shownum.setVisibility(View.INVISIBLE);
        mCount=0;
        mNum=0;
        if(num>channelDatas.getLastChannel()||num<1)return;



        HashMap<String, Integer> map=channelDatas.getChannel(num);

        try {
            if(channelDatas.size()<=map.get("type")){
                return;
            }
            if(!channelDatas.get(map.get("type")).psw.isEmpty()&&!channelDatas.get(map.get("type")).hasPassed){
                return;
            }
        } catch (Exception e) {
        }

        curType=map.get("type");
        curChannelIndex=map.get("pos");

        playVideo();
    }

//按下返回键
    @Override
    public boolean onKeyDown(int keyCode, KeyEvent event) {
        switch (keyCode) {
            case KeyEvent.KEYCODE_DPAD_CENTER:
            case KeyEvent.KEYCODE_ENTER:
                if(mCount>0){
                    sendMessage(Play.ENTERCHANNEL);
                }else{
                    showChannelList();
                }
                break;
            case KeyEvent.KEYCODE_MENU:
                showSetting();
                break;

            case KeyEvent.KEYCODE_DPAD_UP:
                if(reverseUD){
                    movePre();
                }else{
                    moveNext();
                }
                break;
            case KeyEvent.KEYCODE_DPAD_DOWN:
                if(reverseUD){
                    moveNext();
                }else{
                    movePre();
                }
                break;
            case KeyEvent.KEYCODE_DPAD_LEFT:
                if(mCanSeek){
                    if(ijkVideoView.getVisibility()==View.VISIBLE){
                        ijkVideoView.showProgressBar(this, this);
                    }else{
                        mVideoView.showProgressBar(this, this);
                    }
                }else{
                    moveLeft();
                }
                break;
            case KeyEvent.KEYCODE_DPAD_RIGHT:
                if(mCanSeek){
                    if(ijkVideoView.getVisibility()==View.VISIBLE){
                        ijkVideoView.showProgressBar(this, this);
                    }else{
                        mVideoView.showProgressBar(this, this);
                    }
                }else{
                    moveRight();
                }
                break;
            case KeyEvent.KEYCODE_BACK:
                /*if ((System.currentTimeMillis() - exitTime) > 2000) {
                 Toast.makeText(getApplicationContext(), "再按一次返回退出", Toast.LENGTH_SHORT).show();
                 exitTime = System.currentTimeMillis();
                 } else {
                 finish();
                 System.exit(0);
                 }*/
                showExitDialog();
                return true;

            case KeyEvent.KEYCODE_0:
            case KeyEvent.KEYCODE_1:
            case KeyEvent.KEYCODE_2:
            case KeyEvent.KEYCODE_3:
            case KeyEvent.KEYCODE_4:
            case KeyEvent.KEYCODE_5:
            case KeyEvent.KEYCODE_6:
            case KeyEvent.KEYCODE_7:
            case KeyEvent.KEYCODE_8:
            case KeyEvent.KEYCODE_9:

                if(mCount<5){
                    mNum=mNum*10+keyCode-7;
                    tv_shownum.setTextSize(fontSize+20);
                    tv_shownum.setTextColor(Color.rgb(0x8d, 0xed, 0x34));
                    tv_shownum.getPaint().setFakeBoldText(true);
                    tv_shownum.setText(mNum+"");
                    tv_shownum.setVisibility(View.VISIBLE);
                    mCount++;
                }
                if(rEnterChannel!=null){
                    handler.removeCallbacks(rEnterChannel);
                }else{
                    rEnterChannel=new Runnable() {
                        @Override
                        public void run() {
                            sendMessage(Play.ENTERCHANNEL);
                        }
                    };
                }
                if(mCount>=5){
                    handler.removeCallbacks(rEnterChannel);
                    sendMessage(Play.ENTERCHANNEL);
                }else{
                    handler.postDelayed(rEnterChannel, 2000);
                }
                break;
            default:
                break;
        }
        return super.onKeyDown(keyCode, event);
    }
//显示退出对话框
    private void showExitDialog(){
        LayoutInflater inflater = getLayoutInflater();
        View exitView = inflater.inflate(R.layout.exit_dialog,null); 

        tv_userinfo=(TextView) exitView.findViewById(R.id.tv_userinfo);
        tv_isp=(TextView) exitView.findViewById(R.id.tv_isp);
        tv_qqinfo=(TextView) exitView.findViewById(R.id.tv_qqinfo);
        tv_version=(TextView)exitView.findViewById(R.id.tv_versioninfo);

        btn_exit=(Button) exitView.findViewById(R.id.btn_exit);
        btn_setting=(Button) exitView.findViewById(R.id.btn_setting);


        LayoutParams params=btn_exit.getLayoutParams();
        params.height=getScreenHeight()/10;
        btn_exit.setLayoutParams(params);
        btn_setting.setLayoutParams(params);
        btn_exit.setTextSize(TypedValue.COMPLEX_UNIT_PX,fontSize*12/10);
        btn_setting.setTextSize(TypedValue.COMPLEX_UNIT_PX,fontSize*12/10);


        String dayString=SplashActivity.avalibledDays+"";
        if(SplashActivity.status==999){
            dayString="永不到期";
        }
        tv_userinfo.setText(
            "账号："+SplashActivity.userid+"\n"
            + "设备名："+SplashActivity.model+"\n"
            + "到期天数："+dayString+"\n"
            + "当前套餐：" + SplashActivity.meal + "\n"
        );
        tv_userinfo.setTextSize(TypedValue.COMPLEX_UNIT_PX,fontSize);
        tv_userinfo.setTextColor(Color.rgb(0x0, 0xa6, 0xff));   

        tv_isp.setText(SplashActivity.strLocation);
        tv_isp.setTextSize(TypedValue.COMPLEX_UNIT_PX,fontSize);
        tv_isp.setTextColor(Color.rgb(0x0, 0xa6, 0xff));    


        tv_qqinfo.setText(SplashActivity.qqinfo);
        tv_qqinfo.setTextSize(TypedValue.COMPLEX_UNIT_PX,fontSize);
        tv_qqinfo.setTextColor(Color.WHITE);
        if(SplashActivity.status==5){
            tv_userinfo.setVisibility(View.GONE);
        }
        tv_webadmin=(TextView)exitView.findViewById(R.id.tv_webadmin);
        tv_webadmin.setText("本机："+ChannelManager.getLocalIpAddress()+":"+WebServer.port);
        tv_webadmin.setTextSize(TypedValue.COMPLEX_UNIT_PX,fontSize*8/10);

        verSettingText="ver："+SplashActivity.myappver;
        tv_version.setText(verSettingText);
        tv_version.setTextSize(TypedValue.COMPLEX_UNIT_PX,fontSize*8/10);

        btn_exit.setOnClickListener(new OnClickListener() {
                @Override
                public void onClick(View arg0) {
                    finish();
                    System.exit(0);
                }
            });
        btn_setting.setOnClickListener(new OnClickListener() {
                @Override
                public void onClick(View arg0) {
                    showSetting();
                    dialog.dismiss();
                }
            });
        btn_exit.requestFocus();

        dialog = new PopupWindow(exitView, getScreenWidth()*3/5, LayoutParams.WRAP_CONTENT);
        dialog.setBackgroundDrawable(new ColorDrawable(Color.TRANSPARENT));
        dialog.setFocusable(true);
        dialog.setOutsideTouchable(true);
        dialog.update();
        dialog.showAtLocation(ijkVideoView, Gravity.CENTER, 0, 0);
    }
//向左移动
    private void moveLeft() {
        if(channelSourceArrayList.size()==1)return;
        if(curSourceIndex>0){
            curSourceIndex--;
        }else{
            curSourceIndex=channelSourceArrayList.size()-1;
        }
        try {
            setVideo();
        } catch (Exception e) {
            e.printStackTrace();
        }
    }
//向右移动
    private void moveRight() {
        if(channelSourceArrayList.size()==1)return;
        if(curSourceIndex<channelSourceArrayList.size()-1){
            curSourceIndex++;
        }else{
            curSourceIndex=0;
        }
        try {
            setVideo();
        } catch (Exception e) {
            e.printStackTrace();
        }
    }
//移动前置器
    private void movePre() {
        if(curChannelIndex>0){
            curChannelIndex--;
        }else{
            curChannelIndex=channelDatas.get(curType).data.size()-1;
        }
        playVideo();
    }
//移动下一个
    private void moveNext() {   
        if(curChannelIndex<channelDatas.get(curType).data.size()-1){
            curChannelIndex++;
        }else{
            curChannelIndex=0;
        }
        playVideo();
    }

//发送消息
    private void sendMessage(int what) {
        Message msg = new Message();
        msg.what = what;
        handler.sendMessage(msg);
    }
    private void sendMessage(int what,String obj) {
        Message msg = new Message();
        msg.what = what;
        msg.obj=obj;
        handler.sendMessage(msg);
    }

//显示EPG
    private void showEPG() {
        tv_channelnum.setText(channelDatas.get(curType).data.get(curChannelIndex).num);
        tv_channelnum.setTextSize(TypedValue.COMPLEX_UNIT_PX,fontSize+8);
        tip_chname.setText(channelDatas.get(curType).data.get(curChannelIndex).name);
        tip_chname.setTextSize(TypedValue.COMPLEX_UNIT_PX,fontSize+8);
        tv_tiploading.setTextSize(TypedValue.COMPLEX_UNIT_PX,fontSize);

        LayoutParams params=tip_chname.getLayoutParams();
        params.width=(int) getTextViewWidth("湖南卫视湖南卫视", tip_chname);
        tip_chname.setLayoutParams(params);

        if(epgData.get(3).equals("ok")){
            tv_curepg_left.setText("正在播放：");
            tv_nextepg_left.setText("即将播放：");
        }else{
            tv_curepg_left.setText("上一节目：");
            tv_nextepg_left.setText("下一节目：");
        }

        tv_curepg_left.setTextSize(TypedValue.COMPLEX_UNIT_PX,fontSize-7);
        tv_nextepg_left.setTextSize(TypedValue.COMPLEX_UNIT_PX,fontSize-7);
        tip_epg1.setTextSize(TypedValue.COMPLEX_UNIT_PX,fontSize-7);
        tip_epg2.setTextSize(TypedValue.COMPLEX_UNIT_PX,fontSize-7);

        tip_epg1.setText(epgData.get(0));
        tip_epg2.setText(epgData.get(1));

        params=ll_epginfo.getLayoutParams();
        params.width=(int) getTextViewWidth("湖南卫视湖南卫视", tip_chname);
        ll_epginfo.setLayoutParams(params);

        tv_srcinfo.setText("源"+ (curSourceIndex+1)+"/"+channelSourceArrayList.size());
        ll_loading.setVisibility(View.VISIBLE);
        ll_epg.setVisibility(View.VISIBLE);
    }

//隐藏EPG
    private void hideEPG(long delay){
        ll_loading.setVisibility(View.GONE);
        if(rHideEpg!=null){
            handler.removeCallbacks(rHideEpg);
        }else{
            rHideEpg=new Runnable() {
                @Override
                public void run() {
                    sendMessage(Play.HIDE_EPG);
                }
            };
        }
        handler.postDelayed(rHideEpg, delay);
    }

//让时间变长
    private long getTimeLong(String timeString){
        try {
            SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
            Date d1 = sdf.parse(timeString);
            return d1.getTime();
        } catch (ParseException e) {
            e.printStackTrace();
        }
        return 0;
    }


    private String httpget(String geturl) {
        try {
            URL url=new URL(geturl );

            URLConnection connection=url.openConnection();
            connection.setRequestProperty("accept", "*/*");
            connection.setRequestProperty("connection", "Keep-Alive");
            connection.setRequestProperty("user-agent","MTV");
            connection.connect();
            String result="";
            BufferedReader in=new BufferedReader(new InputStreamReader(connection.getInputStream(),"UTF-8"));
            String line;
            while ((line = in.readLine()) != null) {
                result += line+"\n";
            }
            return result;
        } catch (Exception e) {
            return "";
        }
    }


    @Override
    public boolean onDown(MotionEvent arg0) {
        return false;
    }
    @Override
    public boolean onFling(MotionEvent arg0, MotionEvent arg1, float arg2,
                           float arg3) {
        return false;
    }
    @Override
    public void onLongPress(MotionEvent arg0) {
        showSetting();
    }
    @Override
    public boolean onScroll(MotionEvent e1, MotionEvent e2, float distanceX,
                            float distanceY) {
        x1 = e1.getX();

        Math.max(distanceX, distanceY);

        if(startScroll){
            if(Math.abs(distanceX)>Math.abs(distanceY)){
                if(distanceX>0){
                    if(mCanSeek){
                        if(ijkVideoView.getVisibility()==View.VISIBLE){
                            ijkVideoView.showProgressBar(this, this);
                        }
                    }else{
                        moveLeft();
                    }
                }else{
                    if(mCanSeek){
                        if(ijkVideoView.getVisibility()==View.VISIBLE){
                            ijkVideoView.showProgressBar(this, this);
                        }
                    }else{
                        moveRight();
                    }
                }
            }else{
                if(x1>getScreenWidth()/2){
                    //屏幕右侧
                    if(distanceY>0){
                        //上滑
                        if(reverseUD){
                            movePre();
                        }else{
                            moveNext();
                        }
                    }else{
                        if(reverseUD){
                            moveNext();
                        }else{
                            movePre();
                        }
                    }
                }

            }
        }
        if(Math.abs(distanceX)<Math.abs(distanceY)&&x1<getScreenWidth()/2){
            //屏幕左侧
            int delta=0;
            if(Math.abs(distanceY)>10){
                if(distanceY<0){
                    delta=-1;
                }else{
                    delta=1;
                }
            }

            currentVolume =Math.min(maxVolume,Math.max(0,currentVolume+delta));
            mAudioManager.setStreamVolume(AudioManager.STREAM_MUSIC,currentVolume,0);

            tv_voluminfo.setText("音量   "+currentVolume*100/maxVolume+"%");
            tv_voluminfo.setTextSize(TypedValue.COMPLEX_UNIT_PX,fontSize*3/2);
            tv_voluminfo.setVisibility(View.VISIBLE);

            if(rVolume==null){
                rVolume = new Runnable() {
                    @Override
                    public void run() {
                        sendMessage(Play.HIDE_VOLUME);
                    }
                };
            }else{
                handler.removeCallbacks(rVolume);
            }
            handler.postDelayed(rVolume, 2000);
        }


        startScroll=false;
        return false;
    }
    @Override
    public void onShowPress(MotionEvent arg0) {

    }
    @Override
    public boolean onSingleTapUp(MotionEvent event) {
        showChannelList();
        return false;
    }




    @Override
    public boolean onTouchEvent(MotionEvent event) {
        if(event.getAction()==MotionEvent.ACTION_DOWN){
            startScroll=true;
            currentVolume = mAudioManager.getStreamVolume(AudioManager.STREAM_MUSIC);
        }
        return  gestureDetector.onTouchEvent(event);// super.onTouchEvent(event);
    }



    @Override
    public void onUrlChanged(String url) {
        sendMessage(Play.PLAY_VJMS, url);
    }

    public class TVBusBroadcast extends BroadcastReceiver{
        @Override
        public void onReceive(Context context, Intent intent) {
            if(intent.getAction()=="TVBUS_ONPREPARED"){
                sendMessage(Play.RELOAD);
            }
        }

    }


}

