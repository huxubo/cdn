package com.vv.test;

import java.util.ArrayList;

import android.R.integer;

public class ChannelObject {
	public int num;
	public String name;
	public ArrayList<String> source=new ArrayList<String>();
	
	public String getfavor(){
		return name+source.toString();
	}
	public String toJson(){
		String json="";
		json="{\"num\":"+num+",\"name\":\""+name+"\",\"source\":[";
		for(int i=0;i<source.size();i++){
			if(i==0){
				json+="\""+source.get(i)+"\"";
			}else{
				json+=",\""+source.get(i)+"\"";
			}
		}
		json+="]}";
		return json;
	}
}
