package com.webserver;

import com.koushikdutta.async.http.server.AsyncHttpServer;

public class WebServer {
	public final static int port=12315;
	public WebServerCallback callback;
	public void play(String url){
		callback.play(url);
	}
	public void setCallback(WebServerCallback callback){
		this.callback=callback;
	}
	public void start(){
        AsyncHttpServer httpServer=new AsyncHttpServer();
        httpServer.get("/", new HttpRequest("index.html"));
        httpServer.get("/index.html", new HttpRequest("index.html"));
        httpServer.get("/bandr.html", new HttpRequest("bandr.html"));
        httpServer.get("/testurl.html", new HttpRequest("testurl.html"));
        httpServer.get("/bootstrap.min.css", new HttpRequest("bootstrap.min.css"));
        httpServer.get("/toastr.css", new HttpRequest("toastr.css"));
        httpServer.get("/toastr.js", new HttpRequest("toastr.js"));
        httpServer.get("/bootstrap.min.js", new HttpRequest("bootstrap.min.js"));
        httpServer.get("/jquery.min.js", new HttpRequest("jquery.min.js"));
        httpServer.get("/bundle.js", new HttpRequest("bundle.js"));
        httpServer.get("/api/categories.json", new HttpRequestRead());
        httpServer.post("/api/category.json", new HttpRequestSave());
        httpServer.get("/api/delete.json", new HttpRequestDel());
        httpServer.listen(port);
	}
	
}

