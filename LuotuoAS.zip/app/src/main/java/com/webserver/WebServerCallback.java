package com.webserver;

public abstract interface WebServerCallback {
	public abstract void play(String url);

}
