package com.webserver;

import com.koushikdutta.async.http.server.AsyncHttpServerRequest;
import com.koushikdutta.async.http.server.AsyncHttpServerResponse;
import com.koushikdutta.async.http.server.HttpServerRequestCallback;
import com.vv.test.R;

public class HttpRequest implements HttpServerRequestCallback {

	private String filename;
	public HttpRequest(String filename){
		this.filename=filename;
	}
	@Override
	public void onRequest(AsyncHttpServerRequest req,AsyncHttpServerResponse resp) {
		if (this.filename.contains(".css")) {
			resp.send("text/css");
		}
		resp.send(FileUtils.readassetfile(filename));
	}


}


