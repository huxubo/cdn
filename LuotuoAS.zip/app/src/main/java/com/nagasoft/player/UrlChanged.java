package com.nagasoft.player;

public interface UrlChanged {
    void onUrlChanged(String str);
}
