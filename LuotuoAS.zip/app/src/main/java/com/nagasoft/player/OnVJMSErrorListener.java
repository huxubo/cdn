package com.nagasoft.player;

public interface OnVJMSErrorListener {
    void onVJMSError(int i);
}
